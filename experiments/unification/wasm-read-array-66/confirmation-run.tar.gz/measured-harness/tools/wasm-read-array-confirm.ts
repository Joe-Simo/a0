/** Separately sealed confirmation of the original read-array observations; no automatic verdict. */
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { writeReport } from './scrub-results.js';
import { systemLoadTriple } from './system-load.js';
import {
  executable,
  type Group,
  harness,
  type Prepared,
  type Sample,
  type TimingLabel,
  timedBlock,
  type Validation,
  verifyFrozen,
} from './wasm-read-array-timing.js';

const hash = (value: string | Uint8Array) => createHash('sha256').update(value).digest('hex');
const fingerprint = (value: unknown) => hash(JSON.stringify(value));
const ORIGINAL_SELECTION_SHA256 =
  'bd75c17e2740f2373547ba88a2282f289534a692c35143765293b5837c0f18a9';
export const CONFIRMATION_PROTOCOL = {
  schema: 1,
  selection:
    'Every original physical group whose runtime count is zero or one; literal and dynamic, all four lengths and both invocation paths. Exactly 32 groups, including every original observed loss.',
  layouts: ['natural-primary', 'common-address-secondary'],
  natural:
    'Unchanged original per-module heap/stack/host-buffer placement; primary delivered-artifact outcome.',
  secondary:
    'Host array address is ceil(max(original old/new array address)/64)*64. Result/stream follow the unchanged shared layout. Module bytes and internal stack/global values are unchanged. Secondary results never replace natural results.',
  arms: ['oldA', 'oldB', 'newA', 'newB'],
  instanceIsolation:
    'Four independent memories/instances in each child; exact same complete old bytes for oldA/B and complete new bytes for newA/B. Two fresh Node-process replicates per context. No claim of independent native code: engine module/code sharing is unobservable.',
  order:
    'Rotate [oldA,newA,oldB,newB] by context index + process replicate + round; rotate creation order by context index + process replicate. Eight accepted rounds give each arm every position twice.',
  processReplicates: 2,
  warmupRounds: 1,
  measuredRounds: 8,
  targetCalibrationMs: 40,
  budgetGuard: 1.5,
  minAcceptedBlockMs: 20,
  maxBlockMs: 2000,
  initialRepetitions: 64,
  maxRepetitions: 4_194_304,
  maxCalibrationSteps: 18,
  maxLoad1: 10,
  childTimeoutMs: 45_000,
  maxRunMs: 600_000,
  resetAndObservation:
    'Exactly the original shared execution/reset/oracle logic: whole-memory restore outside timers; position reset, JS calls and result/checksum observation inside each timed repetition. Batch contains 64 dependent A0 rounds.',
  budgetFreeze:
    'Freeze selection/layouts/order/calibration/caps/harness before clocks; calibrate all 64 contexts, then freeze every common repetition budget before any accepted rounds in either process replicate.',
  analysis:
    'Preserve original results separately. Report all four raw arms, geometric per-round new/old ratios, disjoint newA/oldA and newB/oldB medians, oldB/oldA and newB/newA clone ratios, signs and process consistency. An even-count median averages the two central observations. Flag every median above one. No baseline/clone subtraction, significance assertion, posthoc noise dismissal or automatic promotion/no-regression conclusion.',
} as const;
type Arm = (typeof CONFIRMATION_PROTOCOL.arms)[number];
type Layout = (typeof CONFIRMATION_PROTOCOL.layouts)[number];
type Block = Sample & { round: number; warmup: boolean; arm: Arm };
interface Context {
  id: string;
  index: number;
  group: Group;
  layout: Layout;
  arrayBase?: number;
  validation: Record<Arm, Validation>;
  identity: string;
}
interface OriginalSelection {
  harness: { commit: string; files: Record<string, string> };
  groups: Group[];
  labels: { label: TimingLabel; validation: Validation[]; aliasIdentity: string }[];
}
interface WorkerInput {
  schema: 1;
  phase: 'calibrate' | 'measure';
  context: Context;
  replicate: number;
  frozenDirectory: string;
  output: string;
  repetitions?: number;
  protocol: typeof CONFIRMATION_PROTOCOL;
}
interface PhaseReport {
  status: string;
  phase: string;
  context: string;
  identity: string;
  replicate: number;
  repetitions: number;
  samples: Block[];
}

export function confirmationGroups(groups: readonly Group[], losses: readonly string[]): Group[] {
  const selected = groups.filter(
    (group) => group.representative.count === 0 || group.representative.count === 1,
  );
  assert.equal(selected.length, 32);
  assert.equal(selected.filter((group) => group.representative.count === 0).length, 16);
  for (const id of losses)
    assert.ok(
      selected.some((group) => group.id === id),
      `original loss omitted: ${id}`,
    );
  return selected;
}

export function confirmationOrder(context: number, replicate: number, round: number): Arm[] {
  const base: Arm[] = ['oldA', 'newA', 'oldB', 'newB'];
  const shift = (((context + replicate + round) % 4) + 4) % 4;
  return base.map((_, index) => base[(index + shift) % 4] as Arm);
}

export function commonArrayBase(group: Group): number {
  return (
    Math.ceil(Math.max(...group.validation.map((value) => value.abiArguments[1] as number)) / 64) *
    64
  );
}

const median = (values: readonly number[]) => {
  assert.ok(values.length > 0);
  const sorted = [...values].sort((a, b) => a - b);
  return (
    ((sorted[Math.floor((sorted.length - 1) / 2)] as number) +
      (sorted[Math.floor(sorted.length / 2)] as number)) /
    2
  );
};

export function confirmationAnalysis(samples: readonly Block[]) {
  const accepted = samples.filter((sample) => !sample.warmup);
  const medians = Object.fromEntries(
    CONFIRMATION_PROTOCOL.arms.map((arm) => {
      const values = accepted.filter((sample) => sample.arm === arm);
      assert.equal(values.length, CONFIRMATION_PROTOCOL.measuredRounds);
      return [arm, median(values.map((sample) => sample.milliseconds))];
    }),
  ) as Record<Arm, number>;
  const rounds = Array.from({ length: CONFIRMATION_PROTOCOL.measuredRounds }, (_, round) => {
    const ms = Object.fromEntries(
      CONFIRMATION_PROTOCOL.arms.map((arm) => {
        const rows = accepted.filter((sample) => sample.round === round && sample.arm === arm);
        assert.equal(rows.length, 1);
        return [arm, (rows[0] as Block).milliseconds];
      }),
    ) as Record<Arm, number>;
    return {
      round,
      geometricNewToOld: Math.sqrt((ms.newA * ms.newB) / (ms.oldA * ms.oldB)),
      newAToOldA: ms.newA / ms.oldA,
      newBToOldB: ms.newB / ms.oldB,
      oldCloneRatio: ms.oldB / ms.oldA,
      newCloneRatio: ms.newB / ms.newA,
    };
  });
  const ratio = Math.sqrt((medians.newA * medians.newB) / (medians.oldA * medians.oldB));
  return {
    mediansMs: medians,
    geometricRatioOfMedians: ratio,
    disjointMedianRatios: {
      newAToOldA: medians.newA / medians.oldA,
      newBToOldB: medians.newB / medians.oldB,
    },
    cloneMedianRatios: {
      oldBToOldA: medians.oldB / medians.oldA,
      newBToNewA: medians.newB / medians.newA,
    },
    rounds,
    observedMedianLoss: ratio > 1,
    allEightRoundRatiosAboveOne: rounds.every((round) => round.geometricNewToOld > 1),
    bothDisjointMedianRatiosAboveOne: medians.newA > medians.oldA && medians.newB > medians.oldB,
  };
}

async function subjects(
  root: string,
  label: TimingLabel,
  arrayBase: number | undefined,
  order: readonly Arm[],
) {
  const result = {} as Record<Arm, Awaited<ReturnType<typeof executable>>>;
  for (const arm of order) {
    const subject = await executable(root, label, arm.startsWith('old') ? 0 : 1, arrayBase);
    result[arm] = { ...subject, arm };
  }
  assert.deepEqual(result.oldA.validation, result.oldB.validation, 'old clone state differs');
  assert.deepEqual(result.newA.validation, result.newB.validation, 'new clone state differs');
  if (arrayBase !== undefined)
    for (const arm of CONFIRMATION_PROTOCOL.arms)
      assert.deepEqual(
        result[arm].validation.abiArguments,
        result.oldA.validation.abiArguments,
        'secondary ABI addresses differ',
      );
  return result;
}

const load = () => [...systemLoadTriple()];
function requireQuiet(values: readonly number[]): void {
  assert.ok(
    values.every(Number.isFinite) && (values[0] as number) <= CONFIRMATION_PROTOCOL.maxLoad1,
    'loaded run: preserve samples and discard performance claim',
  );
}

async function worker(path: string): Promise<void> {
  const input = JSON.parse(await readFile(path, 'utf8')) as WorkerInput;
  assert.deepEqual(input.protocol, CONFIRMATION_PROTOCOL);
  const { context } = input;
  const instances = await subjects(
    input.frozenDirectory,
    context.group.representative,
    context.arrayBase,
    confirmationOrder(context.index, input.replicate, 0),
  );
  for (const arm of CONFIRMATION_PROTOCOL.arms)
    assert.deepEqual(instances[arm].validation, context.validation[arm]);
  const samples: Block[] = [];
  let repetitions = input.repetitions ?? CONFIRMATION_PROTOCOL.initialRepetitions;
  const persist = async (status: string, error?: string) =>
    writeReport(input.output, {
      schema: 1,
      status,
      phase: input.phase,
      context: context.id,
      identity: context.identity,
      replicate: input.replicate,
      repetitions,
      samples,
      node: process.version,
      v8: process.versions.v8,
      ...(error === undefined ? {} : { error }),
    });
  const block = async (arm: Arm, round: number, warmup: boolean) => {
    const sample = await timedBlock(instances[arm], context.group.representative.path, repetitions);
    const recorded = { ...sample, arm, round, warmup };
    samples.push(recorded);
    await persist('running');
    assert.ok(sample.valid, sample.error);
    requireQuiet(sample.loadBefore);
    requireQuiet(sample.loadAfter);
    assert.ok(sample.milliseconds <= CONFIRMATION_PROTOCOL.maxBlockMs, 'block cap exceeded');
    return recorded;
  };
  try {
    if (input.phase === 'calibrate') {
      let reached = false;
      for (let step = 0; step < CONFIRMATION_PROTOCOL.maxCalibrationSteps; step++) {
        const values: Block[] = [];
        for (const arm of confirmationOrder(context.index, 0, step))
          values.push(await block(arm, step, true));
        if (
          Math.min(...values.map((sample) => sample.milliseconds)) >=
          CONFIRMATION_PROTOCOL.targetCalibrationMs
        ) {
          repetitions = Math.min(
            CONFIRMATION_PROTOCOL.maxRepetitions,
            Math.ceil(repetitions * CONFIRMATION_PROTOCOL.budgetGuard),
          );
          reached = true;
          break;
        }
        assert.ok(
          repetitions < CONFIRMATION_PROTOCOL.maxRepetitions,
          'repetition cap reached before calibration target',
        );
        repetitions = Math.min(CONFIRMATION_PROTOCOL.maxRepetitions, repetitions * 2);
      }
      assert.ok(reached, 'calibration cap reached; no undersized-block claim');
    } else {
      assert.ok(
        input.repetitions && repetitions > 0 && repetitions <= CONFIRMATION_PROTOCOL.maxRepetitions,
      );
      for (let round = -1; round < CONFIRMATION_PROTOCOL.measuredRounds; round++)
        for (const arm of confirmationOrder(context.index, input.replicate, round)) {
          const sample = await block(arm, round, round < 0);
          assert.ok(
            sample.milliseconds >= CONFIRMATION_PROTOCOL.minAcceptedBlockMs,
            'undersized sample: preserve and discard performance claim',
          );
        }
    }
    await persist('complete');
  } catch (error) {
    await persist('failed', String(error));
    throw error;
  }
}

async function main(): Promise<void> {
  const args = new Map(
    process.argv.slice(2).map((arg) => {
      const at = arg.indexOf('=');
      return at < 0 ? [arg, ''] : [arg.slice(0, at), arg.slice(at + 1)];
    }),
  );
  const workerArg = args.get('--worker');
  if (workerArg !== undefined) return worker(workerArg);
  for (const name of args.keys())
    assert.ok(
      [
        '--run',
        '--prepare-only',
        '--prepared',
        '--original-selection',
        '--original-harness',
        '--baseline',
        '--candidate',
        '--out',
      ].includes(name),
    );
  assert.ok(!(args.has('--run') && args.has('--prepare-only')));
  const runStart = args.has('--run') ? performance.now() : undefined;
  for (const name of [
    '--prepared',
    '--original-selection',
    '--original-harness',
    '--baseline',
    '--candidate',
    '--out',
  ])
    assert.ok(args.get(name), `required ${name}=PATH`);
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
  const preparedPath = resolve(args.get('--prepared') as string),
    frozenDirectory = dirname(preparedPath);
  const originalPath = resolve(args.get('--original-selection') as string),
    originalHarness = resolve(args.get('--original-harness') as string);
  const baseline = resolve(args.get('--baseline') as string),
    candidate = resolve(args.get('--candidate') as string),
    out = resolve(args.get('--out') as string);
  const preparedText = await readFile(preparedPath),
    originalText = await readFile(originalPath);
  const originalResultsPath = join(dirname(originalPath), 'results.json'),
    originalResultsText = await readFile(originalResultsPath);
  assert.equal(hash(originalText), ORIGINAL_SELECTION_SHA256);
  const prepared = JSON.parse(preparedText.toString()) as Prepared,
    original = JSON.parse(originalText.toString()) as OriginalSelection;
  const originalResults = JSON.parse(originalResultsText.toString()) as {
    status: string;
    regressions: string[];
  };
  assert.equal(originalResults.status, 'complete');
  assert.equal(original.harness.commit, '8d1a2afadbb31351550a19a1e347bb7db6b22f10');
  const sharedHarness = await harness(root, [
    'tools/wasm-read-array-confirm.ts',
    'dist/tools/wasm-read-array-confirm.js',
  ]);
  const compilerIdentities = await verifyFrozen(frozenDirectory, prepared, baseline, candidate);
  const verifyOriginalHarness = async () => {
    for (const [path, digest] of Object.entries(original.harness.files))
      assert.equal(
        hash(await readFile(join(originalHarness, path))),
        digest,
        'original measured harness changed',
      );
  };
  await verifyOriginalHarness();
  const selected = confirmationGroups(original.groups, originalResults.regressions);
  const contexts: Context[] = [],
    labels = [];
  for (const group of selected)
    for (const layout of CONFIRMATION_PROTOCOL.layouts) {
      const arrayBase = layout === 'common-address-secondary' ? commonArrayBase(group) : undefined;
      let reference: Record<Arm, Validation> | undefined;
      for (const id of group.labels) {
        const value = original.labels.find((value) => value.label.id === id);
        assert.ok(value);
        const instances = await subjects(
          frozenDirectory,
          value.label,
          arrayBase,
          confirmationOrder(contexts.length, 0, 0),
        );
        const validation = Object.fromEntries(
          CONFIRMATION_PROTOCOL.arms.map((arm) => [arm, instances[arm].validation]),
        ) as Record<Arm, Validation>;
        if (reference === undefined) reference = validation;
        else assert.deepEqual(validation, reference, 'alias workload differs');
        if (layout === 'natural-primary') {
          assert.deepEqual(validation.oldA, value.validation[0]);
          assert.deepEqual(validation.newA, value.validation[1]);
        }
        labels.push({
          originalLabel: id,
          group: group.id,
          layout,
          options: value.label.options,
          modules: value.label.arms,
          validation,
        });
      }
      assert.ok(reference);
      const id = `${group.id}.${layout}`;
      const context = {
        id,
        index: contexts.length,
        group,
        layout,
        ...(arrayBase === undefined ? {} : { arrayBase }),
        validation: reference,
      };
      contexts.push({
        ...context,
        identity: fingerprint({ context, protocol: CONFIRMATION_PROTOCOL }),
      });
    }
  assert.equal(contexts.length, 64);
  assert.equal(labels.length, 768);
  await mkdir(out, { recursive: true });
  const selection = {
    schema: 1,
    status: 'prepared-no-timing',
    protocol: CONFIRMATION_PROTOCOL,
    originalSelectionSHA256: hash(originalText),
    originalResultsSHA256: hash(originalResultsText),
    preparedSHA256: hash(preparedText),
    originalMeasuredHarness: original.harness,
    confirmationHarness: sharedHarness,
    compilerIdentities,
    contexts,
    labels,
    counts: {
      selectedOriginalGroups: 32,
      contexts: 64,
      originalLabelMappings: 384,
      layoutLabelMappings: 768,
      processReplicates: 128,
      plannedRawSubjectBlocks: 4608,
      plannedAcceptedSubjectBlocks: 4096,
    },
    runtime: {
      node: process.version,
      v8: process.versions.v8,
      platform: process.platform,
      arch: process.arch,
    },
    scope:
      'Separate confirmation; original observations remain unchanged. Natural placement is primary. Same-byte clones are process/instance controls, with no assertion about engine native-code independence.',
  };
  const selectionPath = join(out, 'selection.json');
  await writeReport(selectionPath, selection);
  const selectionSHA256 = hash(await readFile(selectionPath));
  const unchanged = async () => {
    assert.equal(hash(await readFile(preparedPath)), hash(preparedText));
    assert.equal(hash(await readFile(originalPath)), hash(originalText));
    assert.equal(hash(await readFile(originalResultsPath)), hash(originalResultsText));
    assert.equal(hash(await readFile(selectionPath)), selectionSHA256);
    assert.deepEqual(
      await harness(root, [
        'tools/wasm-read-array-confirm.ts',
        'dist/tools/wasm-read-array-confirm.js',
      ]),
      sharedHarness,
    );
    assert.deepEqual(
      await verifyFrozen(frozenDirectory, prepared, baseline, candidate),
      compilerIdentities,
    );
    await verifyOriginalHarness();
  };
  await unchanged();
  console.log(
    'PASS all384 original labels validated independently under both layouts/four clone instances;64 contexts frozen',
  );
  if (!args.has('--run')) {
    console.log('Preparation only: no confirmation calibration/timing run');
    return;
  }
  requireQuiet(load());
  assert.ok(runStart !== undefined);
  const start = runStart;
  const budgets: Record<string, { repetitions: number; sha256: string; subjectBlocks: number }> =
    {};
  const runChild = async (
    context: Context,
    phase: WorkerInput['phase'],
    replicate: number,
    repetitions?: number,
  ) => {
    assert.ok(
      performance.now() - start < CONFIRMATION_PROTOCOL.maxRunMs,
      'confirmation deadline exceeded',
    );
    requireQuiet(load());
    const output = join(out, `${context.id}.${phase}.rep${replicate}.json`),
      request = join(out, `${context.id}.${phase}.rep${replicate}.request.json`);
    const input: WorkerInput = {
      schema: 1,
      phase,
      context,
      replicate,
      frozenDirectory,
      output,
      protocol: CONFIRMATION_PROTOCOL,
      ...(repetitions === undefined ? {} : { repetitions }),
    };
    await writeFile(request, `${JSON.stringify(input)}\n`);
    const child = spawnSync(
      process.execPath,
      [fileURLToPath(import.meta.url), `--worker=${request}`],
      {
        encoding: 'utf8',
        timeout: Math.min(
          CONFIRMATION_PROTOCOL.childTimeoutMs,
          Math.max(1, Math.ceil(CONFIRMATION_PROTOCOL.maxRunMs - (performance.now() - start))),
        ),
        maxBuffer: 2 * 1024 * 1024,
      },
    );
    assert.equal(
      child.status,
      0,
      `${context.id}/${phase}/rep${replicate}: ${child.error ?? ''}\n${child.stderr}`,
    );
    assert.ok(performance.now() - start <= CONFIRMATION_PROTOCOL.maxRunMs);
    requireQuiet(load());
    const report = JSON.parse(await readFile(output, 'utf8')) as PhaseReport;
    assert.equal(report.status, 'complete');
    assert.equal(report.context, context.id);
    assert.equal(report.identity, context.identity);
    assert.equal(report.replicate, replicate);
    assert.equal(report.phase, phase);
    return report;
  };
  for (const context of contexts) {
    const report = await runChild(context, 'calibrate', 0);
    budgets[context.id] = {
      repetitions: report.repetitions,
      sha256: hash(await readFile(join(out, `${context.id}.calibrate.rep0.json`))),
      subjectBlocks: report.samples.length,
    };
  }
  const budgetPath = join(out, 'budgets.json');
  await writeReport(budgetPath, {
    schema: 1,
    selectionSHA256,
    protocol: CONFIRMATION_PROTOCOL,
    budgets,
  });
  const budgetSHA256 = hash(await readFile(budgetPath));
  console.log('Frozen all64 confirmation budgets before accepted rounds');
  const raw: PhaseReport[] = [];
  for (let replicate = 0; replicate < CONFIRMATION_PROTOCOL.processReplicates; replicate++)
    for (const context of [...contexts.slice(replicate), ...contexts.slice(0, replicate)]) {
      const budget = budgets[context.id];
      assert.ok(budget);
      const report = await runChild(context, 'measure', replicate, budget.repetitions);
      assert.equal(report.samples.length, 36);
      assert.equal(report.repetitions, budget.repetitions);
      raw.push(report);
    }
  await unchanged();
  assert.equal(hash(await readFile(budgetPath)), budgetSHA256);
  for (const context of contexts)
    assert.equal(
      hash(await readFile(join(out, `${context.id}.calibrate.rep0.json`))),
      budgets[context.id]?.sha256,
    );
  const rows = contexts.map((context) => {
    const reports = raw.filter((report) => report.context === context.id);
    assert.equal(reports.length, 2);
    const processes = reports.map((report) => ({
      replicate: report.replicate,
      repetitions: report.repetitions,
      ...confirmationAnalysis(report.samples),
    }));
    return {
      context: context.id,
      group: context.group.id,
      representative: context.group.representative.id,
      labels: context.group.labels,
      layout: context.layout,
      naturalPrimary: context.layout === 'natural-primary',
      processes,
      bothProcessesMedianAboveOne: processes.every((process) => process.observedMedianLoss),
      bothProcessesAllEightRoundsAboveOne: processes.every(
        (process) => process.allEightRoundRatiosAboveOne,
      ),
    };
  });
  await writeReport(join(out, 'results.json'), {
    schema: 1,
    status: 'complete',
    scope: selection.scope,
    protocol: CONFIRMATION_PROTOCOL,
    selectionSHA256,
    budgetSHA256,
    originalSelectionSHA256: hash(originalText),
    originalResultsSHA256: hash(originalResultsText),
    confirmationHarness: sharedHarness,
    originalMeasuredHarness: original.harness,
    compilerIdentities,
    counts: {
      contexts: 64,
      processReplicates: raw.length,
      rawSubjectBlocks: raw.reduce((n, report) => n + report.samples.length, 0),
      acceptedSubjectBlocks: raw.reduce(
        (n, report) => n + report.samples.filter((sample) => !sample.warmup).length,
        0,
      ),
      calibrationSubjectBlocks: Object.values(budgets).reduce(
        (n, budget) => n + budget.subjectBlocks,
        0,
      ),
    },
    rows,
    raw,
    interpretation:
      'Every positive median is retained, including clone and zero controls. Mixed signs or an effect inside clone variation remains unresolved. Natural outcomes stay primary; secondary placement is diagnostic. No subtraction, statistical-significance or automatic promotion/no-regression claim.',
  });
  console.log(
    'PASS confirmation complete:64 contexts,128 independent process runs; original evidence preserved',
  );
}

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href)
  await main();
