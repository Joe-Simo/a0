/**
 * Execution-only replay of frozen read-array controls. Default/--prepare-only validates
 * every label and freezes exact aliases; --run additionally calibrates and measures.
 * Calibration is part of measurement and requires the coordinated quiet window.
 *
 * node dist/tools/wasm-read-array-timing.js --prepare-only --prepared=DIR/prepared.json
 *   --baseline=DIR --candidate=DIR --out=DIR
 *
 * Modules compile/instantiate outside timers. Samples include JavaScript position reset,
 * calls and checksum observations. The batch path amortizes this over 64 A0 rounds and
 * includes its A0 checksum logic. No result implies whole-application performance.
 */
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { availableParallelism, cpus } from 'node:os';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { writeReport } from './scrub-results.js';
import { systemLoadTriple } from './system-load.js';

const GUARD = 0x735a901f;
const SEED = 0x89abcdef;
const BATCH_TRIPS = 64;
const OUTPUT_CAPACITY = 3;
const hash = (data: string | Uint8Array) => createHash('sha256').update(data).digest('hex');
const jsonHash = (value: unknown) => hash(JSON.stringify(value));
export const READ_ARRAY_TIMING_PROTOCOL = {
  schema: 1,
  paths: ['collect', 'batch'],
  batchTrips: BATCH_TRIPS,
  warmupRounds: 1,
  measuredRounds: 7,
  maxLoad1: 10,
  targetCalibrationMs: 10,
  budgetGuard: 1.5,
  minAcceptedBlockMs: 5,
  maxBlockMs: 2000,
  initialRepetitions: 64,
  maxRepetitions: 4_194_304,
  maxCalibrationSteps: 18,
  maxRunMs: 600_000,
  childTimeoutMs: 45_000,
  reset: 'setUint32(buffered-position,0,true) inside each timed outer repetition',
  observation:
    'h=(imul(h xor result[i mod length],1664525)+1013904223)>>>0; batch also xors its returned A0 checksum; included in each timed outer repetition',
  initialization:
    'Restore every byte of the initialized linear-memory template outside each timed block; every call reads the same borrowed source and buffered words. Position reset remains inside the timer.',
  scope:
    'Execution cost including JavaScript crossing, buffered-position reset and checksum observation. Batch includes 64 dependent A0 rounds and checksum logic. No baseline subtraction and no frontend or application inference.',
} as const;

interface Prepared {
  schema: string;
  status: string;
  frozenFiles: Record<string, string>;
  replay: { file: string; sha256: string };
  identities: {
    label: string;
    initial: { commit: string; tree: string; inputs: Record<string, string> };
    final: { commit: string; tree: string; inputs: Record<string, string> };
  }[];
  rows: {
    id: string;
    length: number;
    counts: number[];
    mode: string;
    count?: number;
    sourceFile: string;
    sourceSHA256: string;
    options: Record<string, unknown> & {
      ioInputCapacity: number;
      ioOutputCapacity: number;
    };
    arms: { label: string; moduleFile: string; moduleSHA256: string; moduleBytes: number }[];
  }[];
}
interface TimingLabel {
  id: string;
  sourceId: string;
  length: number;
  count: number;
  path: 'collect' | 'batch';
  trips: number;
  inputCapacity: number;
  sourceFile: string;
  sourceSHA256: string;
  options: Prepared['rows'][number]['options'];
  arms: Prepared['rows'][number]['arms'];
}
interface Expected {
  array: number[];
  position: number;
  checksum: number;
}
interface Validation {
  initialMemorySHA256: string;
  abiArguments: number[];
  expected: Expected;
  inputSHA256: string;
  resultSHA256: string;
}
interface ValidatedLabel {
  label: TimingLabel;
  validation: Validation[];
  aliasIdentity: string;
}
interface Group {
  id: string;
  representative: TimingLabel;
  labels: string[];
  validation: Validation[];
  aliasIdentity: string;
}
interface Sample {
  arm: string;
  milliseconds: number;
  repetitions: number;
  observation: number;
  loadBefore: number[];
  loadAfter: number[];
  witnessSHA256: string;
  valid: boolean;
  error?: string;
}

function localPath(root: string, path: string): string {
  assert.ok(!isAbsolute(path) && !path.split(/[\\/]/).includes('..'), 'non-local path');
  return join(root, path);
}

export function readArrayTimingLabels(prepared: Prepared): TimingLabel[] {
  return prepared.rows.flatMap((row) =>
    row.counts.flatMap((count) =>
      (['collect', 'batch'] as const).map((path) => ({
        id: `${row.id}/count${count}/${path}`,
        sourceId: row.id,
        length: row.length,
        count,
        path,
        trips: path === 'batch' ? BATCH_TRIPS : 1,
        inputCapacity: row.options.ioInputCapacity,
        sourceFile: row.sourceFile,
        sourceSHA256: row.sourceSHA256,
        options: row.options,
        arms: row.arms,
      })),
    ),
  );
}

export function readArrayAliasIdentity(label: TimingLabel, validation: Validation[]): string {
  assert.equal(validation.length, 2);
  return jsonHash({
    modules: label.arms.map((arm) => ({ label: arm.label, sha256: arm.moduleSHA256 })),
    length: label.length,
    count: label.count,
    path: label.path,
    trips: label.trips,
    inputCapacity: label.inputCapacity,
    outputCapacity: label.options.ioOutputCapacity,
    entry: `a0_${label.path}`,
    validation,
    protocol: READ_ARRAY_TIMING_PROTOCOL,
  });
}

export function groupReadArrayLabels(labels: readonly ValidatedLabel[]): Group[] {
  const groups = new Map<string, Group>();
  const ids = new Set<string>();
  for (const value of labels) {
    assert.ok(!ids.has(value.label.id), 'duplicate label');
    ids.add(value.label.id);
    assert.equal(value.aliasIdentity, readArrayAliasIdentity(value.label, value.validation));
    let group = groups.get(value.aliasIdentity);
    if (group === undefined) {
      group = {
        id: `group${String(groups.size).padStart(3, '0')}`,
        representative: value.label,
        validation: value.validation,
        labels: [],
        aliasIdentity: value.aliasIdentity,
      };
      groups.set(value.aliasIdentity, group);
    }
    group.labels.push(value.label.id);
  }
  return [...groups.values()];
}

const original = (length: number): number[] =>
  Array.from({ length }, (_, i) => (0x9955aaee ^ Math.imul(i + 1, 0x9e3779b9)) >>> 0);
const inputWords = (length: number): number[] =>
  Array.from(
    { length },
    (_, i) => (([0, 0xffffffff, 0x80000000, 1, 0x7fffffff][i % 5] as number) ^ (i % 7)) >>> 0,
  );

function expectedResult(label: TimingLabel, input: readonly number[]): Expected {
  const array = original(label.length);
  let position = 0;
  let checksum = SEED;
  for (let round = 0; round < label.trips; round++) {
    for (let i = 0; i < label.count; i++)
      array[i % label.length] = position < input.length ? (input[position++] as number) : 0;
    checksum = ((checksum ^ (array[round % label.length] as number)) + 2654435761) >>> 0;
  }
  return { array, position, checksum };
}

export function readArrayObservation(
  expected: Expected,
  path: 'collect' | 'batch',
  repetitions: number,
): number {
  let observed = SEED;
  for (let i = 0; i < repetitions; i++) {
    observed =
      (Math.imul(observed ^ (expected.array[i % expected.array.length] as number), 1664525) +
        1013904223) >>>
      0;
    if (path === 'batch') observed = (observed ^ expected.checksum) >>> 0;
  }
  return observed;
}

async function executable(root: string, label: TimingLabel, armIndex: number) {
  const arm = label.arms[armIndex];
  assert.ok(arm);
  const bytes = await readFile(localPath(root, arm.moduleFile));
  assert.equal(hash(bytes), arm.moduleSHA256);
  assert.equal(bytes.length, arm.moduleBytes);
  const module = new WebAssembly.Module(bytes);
  assert.deepEqual(WebAssembly.Module.imports(module), []);
  const instance = new WebAssembly.Instance(module);
  const memory = instance.exports.memory as WebAssembly.Memory;
  const heap = Number((instance.exports.__heap_base as WebAssembly.Global).value);
  const array = heap + 64;
  const result = array + (label.length + 4) * 4;
  const stream = result + (label.length + 6) * 4;
  const end = stream + (label.inputCapacity + OUTPUT_CAPACITY + 5) * 4;
  if (memory.buffer.byteLength < end)
    memory.grow(Math.ceil((end - memory.buffer.byteLength) / 65536));
  const view = new DataView(memory.buffer);
  const get = (at: number) => view.getUint32(at, true);
  const put = (at: number, value: number) => view.setUint32(at, value, true);
  const snapshot = (at: number, count: number) =>
    Array.from({ length: count }, (_, i) => get(at + i * 4));
  for (let at = heap; at < end; at += 4) put(at, GUARD);
  for (const [i, word] of original(label.length).entries()) put(array + i * 4, word);
  const words = inputWords(label.inputCapacity);
  for (const [i, word] of words.entries()) put(stream + i * 4, word);
  put(stream + label.inputCapacity * 4, words.length);
  const position = stream + (label.inputCapacity + 1) * 4;
  put(position, 0);
  put(stream + (label.inputCapacity + 2 + OUTPUT_CAPACITY) * 4, 0);
  const template = new Uint8Array(memory.buffer).slice();
  const expected = expectedResult(label, words);
  const call = instance.exports[`a0_${label.path}`] as (...args: number[]) => void;
  assert.equal(typeof call, 'function');
  const abiArguments = [
    result,
    array,
    stream,
    label.count,
    ...(label.path === 'batch' ? [BATCH_TRIPS, SEED] : []),
  ];
  const sourceBefore = snapshot(array - 4, label.length + 2);
  const inputBefore = snapshot(stream - 4, label.inputCapacity + 2);
  const expectedResultWords = [
    ...expected.array,
    stream,
    ...(label.path === 'batch' ? [expected.checksum] : []),
  ];
  const check = (): string => {
    assert.equal(memory.buffer.byteLength, template.length, 'memory grew during execution');
    assert.deepEqual(snapshot(result, expectedResultWords.length), expectedResultWords);
    assert.equal(get(result - 4), GUARD);
    assert.equal(get(result + expectedResultWords.length * 4), GUARD);
    assert.deepEqual(snapshot(array - 4, label.length + 2), sourceBefore, 'borrowed input changed');
    assert.deepEqual(
      snapshot(stream - 4, label.inputCapacity + 2),
      inputBefore,
      'IO input changed',
    );
    assert.equal(get(position), expected.position);
    assert.deepEqual(
      snapshot(stream + (label.inputCapacity + 2) * 4, OUTPUT_CAPACITY),
      Array(OUTPUT_CAPACITY).fill(GUARD),
    );
    assert.equal(get(stream + (label.inputCapacity + 2 + OUTPUT_CAPACITY) * 4), 0);
    assert.equal(get(stream + (label.inputCapacity + 3 + OUTPUT_CAPACITY) * 4), GUARD);
    return jsonHash({ result: expectedResultWords, position: get(position), canaries: 'pass' });
  };
  const restore = () => new Uint8Array(memory.buffer).set(template);
  /** This loop alone is timed; validation, expected observation and template restore are outside. */
  const block = (repetitions: number): number => {
    let observed = SEED;
    if (label.path === 'collect') {
      for (let i = 0; i < repetitions; i++) {
        view.setUint32(position, 0, true);
        call(result, array, stream, label.count);
        observed =
          (Math.imul(observed ^ view.getUint32(result + (i % label.length) * 4, true), 1664525) +
            1013904223) >>>
          0;
      }
    } else {
      for (let i = 0; i < repetitions; i++) {
        view.setUint32(position, 0, true);
        call(result, array, stream, label.count, BATCH_TRIPS, SEED);
        observed =
          (Math.imul(observed ^ view.getUint32(result + (i % label.length) * 4, true), 1664525) +
            1013904223) >>>
          0;
        observed = (observed ^ view.getUint32(result + (label.length + 1) * 4, true)) >>> 0;
      }
    }
    return observed;
  };
  restore();
  call(...abiArguments);
  const validation: Validation = {
    initialMemorySHA256: hash(template),
    abiArguments,
    expected,
    inputSHA256: jsonHash(words),
    resultSHA256: check(),
  };
  restore();
  return { arm: arm.label, block, check, restore, validation, expected };
}

function git(root: string, ...args: string[]): string {
  return execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim();
}

async function verifyFrozen(root: string, prepared: Prepared, baseline: string, candidate: string) {
  for (const [path, digest] of Object.entries(prepared.frozenFiles))
    assert.equal(
      hash(await readFile(localPath(root, path))),
      digest,
      `frozen file changed: ${path}`,
    );
  const identities = [];
  for (const recorded of prepared.identities) {
    assert.deepEqual(recorded.initial, recorded.final);
    assert.ok(['old64', 'new66'].includes(recorded.label));
    const checkout = recorded.label === 'old64' ? baseline : candidate;
    assert.equal(git(checkout, 'status', '--porcelain', '--untracked-files=normal'), '');
    assert.equal(git(checkout, 'rev-parse', 'HEAD'), recorded.initial.commit);
    assert.equal(git(checkout, 'rev-parse', 'HEAD^{tree}'), recorded.initial.tree);
    for (const [path, digest] of Object.entries(recorded.initial.inputs))
      assert.equal(
        hash(await readFile(localPath(checkout, path))),
        digest,
        `compiler changed: ${path}`,
      );
    identities.push({ label: recorded.label, ...recorded.initial });
  }
  assert.equal(
    hash(await readFile(localPath(candidate, prepared.replay.file))),
    prepared.replay.sha256,
    'original compiled preparation replay changed',
  );
  return identities;
}

async function harness(root: string) {
  assert.equal(git(root, 'status', '--porcelain', '--untracked-files=normal'), '');
  const paths = [
    'tools/wasm-read-array-timing.ts',
    'dist/tools/wasm-read-array-timing.js',
    'tools/system-load.ts',
    'dist/tools/system-load.js',
    'tools/scrub-results.ts',
    'dist/tools/scrub-results.js',
  ];
  return {
    commit: git(root, 'rev-parse', 'HEAD'),
    tree: git(root, 'rev-parse', 'HEAD^{tree}'),
    files: Object.fromEntries(
      await Promise.all(paths.map(async (path) => [path, hash(await readFile(join(root, path)))])),
    ),
  };
}

const quiet = (): number[] => {
  const load = [...systemLoadTriple()];
  assert.ok(
    load.every(Number.isFinite) && (load[0] as number) <= READ_ARRAY_TIMING_PROTOCOL.maxLoad1,
    'loaded machine: discard run',
  );
  return load;
};

async function timedBlock(
  subject: Awaited<ReturnType<typeof executable>>,
  path: 'collect' | 'batch',
  repetitions: number,
): Promise<Sample> {
  subject.restore();
  const expected = readArrayObservation(subject.expected, path, repetitions);
  const loadBefore = quiet();
  const start = performance.now();
  let observation = 0;
  let failure: string | undefined;
  try {
    observation = subject.block(repetitions);
  } catch (error) {
    failure = String(error);
  }
  const milliseconds = performance.now() - start;
  const loadAfter = [...systemLoadTriple()];
  let witnessSHA256 = '';
  try {
    assert.equal(failure, undefined, failure);
    assert.equal(observation, expected, 'timed observation differs');
    witnessSHA256 = subject.check();
  } catch (error) {
    failure = String(error);
  }
  return {
    arm: subject.arm,
    milliseconds,
    repetitions,
    observation,
    loadBefore,
    loadAfter,
    witnessSHA256,
    valid: failure === undefined,
    ...(failure === undefined ? {} : { error: failure }),
  };
}

interface WorkerInput {
  schema: 1;
  phase: 'calibrate' | 'measure';
  group: Group;
  frozenDirectory: string;
  output: string;
  repetitions?: number;
  protocol: typeof READ_ARRAY_TIMING_PROTOCOL;
}

async function worker(path: string): Promise<void> {
  const input = JSON.parse(await readFile(path, 'utf8')) as WorkerInput;
  assert.deepEqual(input.protocol, READ_ARRAY_TIMING_PROTOCOL);
  const label = input.group.representative;
  const subjects = [
    await executable(input.frozenDirectory, label, 0),
    await executable(input.frozenDirectory, label, 1),
  ];
  assert.deepEqual(
    subjects.map((subject) => subject.validation),
    input.group.validation,
  );
  const numericId = Number(input.group.id.slice(5));
  const samples: (Sample & { round: number; warmup: boolean })[] = [];
  let repetitions = input.repetitions ?? READ_ARRAY_TIMING_PROTOCOL.initialRepetitions;
  const persist = async (status: string, error?: string) =>
    writeReport(input.output, {
      schema: 1,
      phase: input.phase,
      status,
      group: input.group.id,
      aliasIdentity: input.group.aliasIdentity,
      repetitions,
      samples,
      node: process.version,
      v8: process.versions.v8,
      ...(error === undefined ? {} : { error }),
    });
  const record = async (sample: Sample, round: number, warmup: boolean) => {
    samples.push({ ...sample, round, warmup });
    await persist('running');
    assert.ok(sample.valid, sample.error);
    assert.ok(
      sample.loadAfter.every(Number.isFinite) &&
        (sample.loadAfter[0] as number) <= READ_ARRAY_TIMING_PROTOCOL.maxLoad1,
      'loaded subject: discard run',
    );
    assert.ok(
      sample.milliseconds <= READ_ARRAY_TIMING_PROTOCOL.maxBlockMs,
      'block exceeded duration cap',
    );
  };
  try {
    if (input.phase === 'calibrate') {
      let reached = false;
      for (let step = 0; step < READ_ARRAY_TIMING_PROTOCOL.maxCalibrationSteps; step++) {
        const pair: Sample[] = [];
        for (let index = 0; index < 2; index++) {
          const subject = subjects[(numericId + step + index) % 2];
          assert.ok(subject);
          const sample = await timedBlock(subject, label.path, repetitions);
          pair.push(sample);
          await record(sample, step, true);
        }
        if (
          Math.min(...pair.map((sample) => sample.milliseconds)) >=
          READ_ARRAY_TIMING_PROTOCOL.targetCalibrationMs
        ) {
          reached = true;
          repetitions = Math.min(
            READ_ARRAY_TIMING_PROTOCOL.maxRepetitions,
            Math.ceil(repetitions * READ_ARRAY_TIMING_PROTOCOL.budgetGuard),
          );
          break;
        }
        assert.ok(
          repetitions < READ_ARRAY_TIMING_PROTOCOL.maxRepetitions,
          'calibration cap: undersized blocks cannot support claims',
        );
        repetitions = Math.min(READ_ARRAY_TIMING_PROTOCOL.maxRepetitions, repetitions * 2);
      }
      assert.ok(reached, 'calibration step cap: undersized blocks cannot support claims');
    } else {
      assert.ok(
        input.repetitions &&
          repetitions > 0 &&
          repetitions <= READ_ARRAY_TIMING_PROTOCOL.maxRepetitions,
      );
      for (let round = -1; round < READ_ARRAY_TIMING_PROTOCOL.measuredRounds; round++) {
        for (let index = 0; index < 2; index++) {
          const subject = subjects[(numericId + round + 1 + index) % 2];
          assert.ok(subject);
          const sample = await timedBlock(subject, label.path, repetitions);
          await record(sample, round, round < 0);
          assert.ok(
            sample.milliseconds >= READ_ARRAY_TIMING_PROTOCOL.minAcceptedBlockMs,
            'undersized sample: discard this case/run, no performance claim',
          );
        }
      }
    }
    await persist('complete');
  } catch (error) {
    await persist('failed', String(error));
    throw error;
  }
}

const median = (values: number[]) =>
  [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)] as number;

async function main(): Promise<void> {
  const args = new Map(
    process.argv.slice(2).map((arg) => {
      const at = arg.indexOf('=');
      return at < 0 ? [arg, ''] : [arg.slice(0, at), arg.slice(at + 1)];
    }),
  );
  const workerArg = args.get('--worker');
  if (workerArg !== undefined) return worker(workerArg);
  for (const name of args.keys())
    assert.ok(
      ['--prepare-only', '--run', '--prepared', '--baseline', '--candidate', '--out'].includes(
        name,
      ),
      `unknown argument ${name}`,
    );
  assert.ok(!(args.has('--prepare-only') && args.has('--run')), 'choose preparation or run');
  for (const name of ['--prepared', '--baseline', '--candidate', '--out'])
    assert.ok(args.get(name), `required ${name}=PATH`);
  const preparedPath = resolve(args.get('--prepared') as string);
  const frozenDirectory = dirname(preparedPath);
  const baseline = resolve(args.get('--baseline') as string);
  const candidate = resolve(args.get('--candidate') as string);
  const out = resolve(args.get('--out') as string);
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
  const preparedText = await readFile(preparedPath, 'utf8');
  const prepared = JSON.parse(preparedText) as Prepared;
  assert.equal(prepared.schema, 'a0-read-array-loop-controls-v1');
  assert.equal(prepared.status, 'prepared-no-timing');
  const initialHarness = await harness(root);
  const identities = await verifyFrozen(frozenDirectory, prepared, baseline, candidate);
  const labels = readArrayTimingLabels(prepared);
  assert.equal(labels.length, 1056, 'frozen corpus selection differs');
  await mkdir(out, { recursive: true });
  const validated: ValidatedLabel[] = [];
  for (const label of labels) {
    const subjects = [
      await executable(frozenDirectory, label, 0),
      await executable(frozenDirectory, label, 1),
    ];
    const validation = subjects.map((subject) => subject.validation);
    validated.push({ label, validation, aliasIdentity: readArrayAliasIdentity(label, validation) });
  }
  const groups = groupReadArrayLabels(validated);
  assert.equal(groups.length, 88, 'frozen executable/input alias groups differ');
  assert.ok(groups.every((group) => group.labels.length === 12));
  const selection = {
    schema: 1,
    status: 'prepared-no-timing',
    preparedSHA256: hash(preparedText),
    harness: initialHarness,
    compilerIdentities: identities,
    protocol: READ_ARRAY_TIMING_PROTOCOL,
    labels: validated,
    groups,
    counts: {
      originalLabels: labels.length,
      measuredGroups: groups.length,
      independentPhysicalPairs: groups.length,
      plannedRawSubjectBlocks: groups.length * 2 * 8,
      plannedAcceptedSubjectBlocks: groups.length * 2 * 7,
    },
    aliasMethod:
      'Every original label is instantiated and checked independently. Exact grouping requires identical paired module hashes, complete initialized linear-memory hashes, ABI and arguments, input values, expected results/IO/checksum/canaries, reset/observation workload and calibration protocol. Raw samples belong only to the physical group; label mappings do not create observations.',
    runtime: {
      node: process.version,
      v8: process.versions.v8,
      platform: process.platform,
      arch: process.arch,
      cpu: cpus()[0]?.model,
      availableParallelism: availableParallelism(),
      workerIsolation:
        'Fresh Node child per physical group and phase; both arms paired inside that child, with rotated order each round.',
    },
  };
  const selectionPath = join(out, 'selection.json');
  await writeReport(selectionPath, selection);
  const selectionSHA256 = hash(await readFile(selectionPath));
  const unchanged = async () => {
    assert.equal(hash(await readFile(preparedPath)), hash(preparedText));
    assert.equal(hash(await readFile(selectionPath)), selectionSHA256);
    assert.deepEqual(await harness(root), initialHarness);
    assert.deepEqual(
      await verifyFrozen(frozenDirectory, prepared, baseline, candidate),
      identities,
    );
  };
  await unchanged();
  console.log(
    `PASS ${labels.length} labels independently validated; ${groups.length} exact physical groups; no samples copied to aliases`,
  );
  if (!args.has('--run')) {
    console.log('Preparation only: no timing or calibration run');
    return;
  }
  quiet();
  const runStart = performance.now();
  const script = fileURLToPath(import.meta.url);
  const raw: {
    group: string;
    repetitions: number;
    samples: (Sample & { round: number; warmup: boolean })[];
  }[] = [];
  const budgets: Record<
    string,
    { repetitions: number; calibrationSHA256: string; calibrationSubjectBlocks: number }
  > = {};
  const runChild = async (group: Group, phase: WorkerInput['phase'], repetitions?: number) => {
    assert.ok(
      performance.now() - runStart <= READ_ARRAY_TIMING_PROTOCOL.maxRunMs,
      'run deadline exceeded; no complete-run claim',
    );
    quiet();
    const output = join(out, `${group.id}.${phase}.json`);
    const request: WorkerInput = {
      schema: 1,
      phase,
      group,
      frozenDirectory,
      output,
      protocol: READ_ARRAY_TIMING_PROTOCOL,
      ...(repetitions === undefined ? {} : { repetitions }),
    };
    const requestPath = join(out, `${group.id}.${phase}.request.json`);
    await writeFile(requestPath, `${JSON.stringify(request)}\n`);
    const result = spawnSync(process.execPath, [script, `--worker=${requestPath}`], {
      encoding: 'utf8',
      timeout: Math.min(
        READ_ARRAY_TIMING_PROTOCOL.childTimeoutMs,
        Math.max(
          1,
          Math.ceil(READ_ARRAY_TIMING_PROTOCOL.maxRunMs - (performance.now() - runStart)),
        ),
      ),
      maxBuffer: 2 * 1024 * 1024,
    });
    assert.equal(result.status, 0, `${group.id}/${phase}: ${result.error ?? ''}\n${result.stderr}`);
    assert.ok(
      performance.now() - runStart <= READ_ARRAY_TIMING_PROTOCOL.maxRunMs,
      'run deadline exceeded',
    );
    quiet();
    const report = JSON.parse(await readFile(output, 'utf8')) as {
      status: string;
      phase: string;
      group: string;
      aliasIdentity: string;
      repetitions: number;
      samples: (Sample & { round: number; warmup: boolean })[];
    };
    assert.equal(report.status, 'complete');
    assert.equal(report.phase, phase);
    assert.equal(report.group, group.id);
    assert.equal(report.aliasIdentity, group.aliasIdentity);
    return report;
  };
  for (const group of groups) {
    const calibration = await runChild(group, 'calibrate');
    budgets[group.id] = {
      repetitions: calibration.repetitions,
      calibrationSHA256: hash(await readFile(join(out, `${group.id}.calibrate.json`))),
      calibrationSubjectBlocks: calibration.samples.length,
    };
  }
  const budgetPath = join(out, 'budgets.json');
  await writeReport(budgetPath, {
    schema: 1,
    selectionSHA256,
    protocol: READ_ARRAY_TIMING_PROTOCOL,
    budgets,
  });
  const budgetSHA256 = hash(await readFile(budgetPath));
  console.log(`Frozen ${groups.length} calibrated budgets before accepted rounds`);
  for (const group of groups) {
    const budget = budgets[group.id];
    assert.ok(budget);
    const measured = await runChild(group, 'measure', budget.repetitions);
    assert.equal(measured.repetitions, budget.repetitions);
    assert.equal(measured.samples.length, 16);
    raw.push(measured);
  }
  await unchanged();
  assert.equal(hash(await readFile(budgetPath)), budgetSHA256);
  for (const group of groups)
    assert.equal(
      hash(await readFile(join(out, `${group.id}.calibrate.json`))),
      budgets[group.id]?.calibrationSHA256,
    );
  const rows = groups.map((group) => {
    const measurement = raw.find((entry) => entry.group === group.id);
    assert.ok(measurement);
    const accepted = measurement.samples.filter((sample) => !sample.warmup);
    const medians = Object.fromEntries(
      ['old64', 'new66'].map((arm) => {
        const samples = accepted.filter((sample) => sample.arm === arm);
        assert.equal(samples.length, 7);
        return [arm, median(samples.map((sample) => sample.milliseconds))];
      }),
    ) as Record<string, number>;
    const pairedRatios = Array.from({ length: 7 }, (_, round) => {
      const old = accepted.find((sample) => sample.round === round && sample.arm === 'old64');
      const current = accepted.find((sample) => sample.round === round && sample.arm === 'new66');
      assert.ok(old && current);
      return current.milliseconds / old.milliseconds;
    });
    const ratio = (medians.new66 as number) / (medians.old64 as number);
    return {
      group: group.id,
      representative: group.representative.id,
      labels: group.labels,
      count: group.representative.count,
      path: group.representative.path,
      length: group.representative.length,
      repetitions: measurement.repetitions,
      mediansMs: medians,
      nsPerInnerCollect: Object.fromEntries(
        Object.entries(medians).map(([arm, ms]) => [
          arm,
          (ms * 1e6) / measurement.repetitions / group.representative.trips,
        ]),
      ),
      ratioNewToOld: ratio,
      pairedRatios,
      observedMedianRegression: ratio > 1,
      allSevenPairsSlower: pairedRatios.every((value) => value > 1),
      zeroControl: group.representative.count === 0,
    };
  });
  await writeReport(join(out, 'results.json'), {
    schema: 1,
    status: 'complete',
    scope: READ_ARRAY_TIMING_PROTOCOL.scope,
    selectionSHA256,
    budgetSHA256,
    harness: initialHarness,
    compilerIdentities: identities,
    protocol: READ_ARRAY_TIMING_PROTOCOL,
    counts: {
      coveredLabels: labels.length,
      physicalGroups: groups.length,
      calibrationSubjectBlocks: Object.values(budgets).reduce(
        (n, budget) => n + budget.calibrationSubjectBlocks,
        0,
      ),
      rawSubjectBlocks: raw.reduce((n, group) => n + group.samples.length, 0),
      acceptedSubjectBlocks: raw.reduce(
        (n, group) => n + group.samples.filter((sample) => !sample.warmup).length,
        0,
      ),
    },
    regressions: rows.filter((row) => row.observedMedianRegression).map((row) => row.group),
    sustainedRegressions: rows.filter((row) => row.allSevenPairsSlower).map((row) => row.group),
    zeroControls: rows.filter((row) => row.zeroControl).map((row) => row.group),
    interpretation:
      'Every median ratio above one is reported as an observed regression, including zero controls. Raw paired samples and duration/load checks bound interpretation; no statistical significance or whole-application causality is asserted. Alias labels are coverage mappings, not independent observations.',
    rows,
    raw,
  });
  console.log(
    `PASS measured ${groups.length} physical groups; ${labels.length} labels covered; ${rows.filter((row) => row.observedMedianRegression).length} observed median regressions`,
  );
}

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href)
  await main();
