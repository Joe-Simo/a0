import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { compile } from '../dist/src/backends.js';
import { formatProgram } from '../dist/src/core.js';
import { link } from '../dist/src/link.js';
import { programRevision } from '../dist/src/revision.js';
import { nativeSource } from '../dist/src/source-native.js';
import { linkNativeSource } from '../dist/src/source-native-link.js';
import { migrateNativeSourceProject } from '../dist/src/source-native-migrate.js';
import { prepareSourceFrontend, prepareSourceFormat } from '../dist/tools/source-native-load.js';
import { writeReport } from '../dist/tools/scrub-results.js';

const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const root = resolve('.');
const output = resolve('.a0-tmp/frozen-1de-applications');
await mkdir(output);
const frontendPath = resolve('.a0-tmp/frozen-1de-c-ports');
const formatPath = resolve('.a0-tmp/frozen-1de-format');
const prepared = await prepareSourceFrontend(frontendPath);
assert.equal(prepared.build.diagnosticPorts, 'arena-v1');
const formatter = await prepareSourceFormat(formatPath);
const frontend = nativeSource(new WebAssembly.Module(await readFile(join(frontendPath, 'frontend.wasm'))), undefined, formatter);
const cases = [
  ['life', 'examples/life.a0'],
  ['frontend', 'compiler/source_frontend.a0'],
  ['boot', 'compiler/boot.a0'],
  ['page', 'site/page.a0'],
  ['docs', 'site/docs.a0'],
  ['parser', 'compiler/parse.a0'],
  ['sitegen', 'site/gen/sitegen.a0'],
  ['c-stage', 'compiler/c_stage_arena.a0'],
];
const rows = [];
const read = (path) => readFile(path, 'utf8');
try {
  for (const [name, entry] of cases) {
    const before = await link(resolve(entry), read, { root });
    const destination = join(output, name);
    const manifest = await migrateNativeSourceProject(resolve(entry), destination, frontend, root);
    const after = await linkNativeSource(join(destination, manifest.entry), read, frontend, { root: destination });
    assert.equal(formatProgram(before.program), formatProgram(after.program));
    assert.equal(programRevision(before.program), manifest.revision);
    assert.equal(programRevision(after.program), manifest.revision);
    const targets = [];
    for (const target of ['js', 'c', 'wasm']) {
      const original = compile(before.program, target);
      const migrated = compile(after.program, target);
      assert.deepEqual(migrated, original, `${name}/${target}`);
      targets.push({ target, bytes: Buffer.byteLength(original.text), sha256: hash(original.text), byteIdentical: true });
    }
    const row = { name, entry, files: manifest.files.length, functions: after.program.functions.length, revision: manifest.revision, targets, manifest };
    rows.push(row);
    console.log(JSON.stringify({ name, files: row.files, functions: row.functions, revision: row.revision, targets }));
    await writeReport(join(output, 'applications.json'), { testedCommit: '1de98295314eb1eb62b519c29ac36ac40307c463', scope: 'Correctness and byte-identical emission only. Busy-host timings are not measurements. Historical reference link and compilation are test oracles; output parsing, formatting, and checking use the same A0 frontend.', rows });
  }
} finally {
  frontend.close();
}
