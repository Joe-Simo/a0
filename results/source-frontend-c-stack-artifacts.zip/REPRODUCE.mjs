import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const analyzer = await import(pathToFileURL(resolve(process.argv[2])).href);
for (const name of ['combined', 'bundled']) {
  const expected = JSON.parse(await readFile(join(root, 'proofs', name + '.json'), 'utf8'));
  const actual = analyzer.wasmStackBound(await readFile(join(root, 'artifacts', name, 'frontend.wasm')));
  assert.deepEqual(actual, expected);
  console.log(JSON.stringify({ artifact: name, artifactSHA256: actual.artifactSHA256,
    functions: actual.functions.length, maxLinearStackBytes: actual.maxLinearStackBytes,
    maxCallDepth: actual.maxCallDepth }));
}
