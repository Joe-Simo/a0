import hashlib, json, pathlib, re, subprocess, sys

root = pathlib.Path(sys.argv[2])
results = []
for name in ["combined", "bundled"]:
    wasm = root / "artifacts" / name / "frontend.wasm"
    proof = json.loads((root / "proofs" / (name + ".json")).read_text())
    assert hashlib.sha256(wasm.read_bytes()).hexdigest() == proof["artifactSHA256"]
    text = subprocess.check_output([sys.argv[1], "-d", str(wasm)], text=True)
    groups = re.split(r"(?m)^\w+ func\[(\d+)\][^\n]*:\n", text)
    inventory = {}
    kinds = {"frameless": 0, "void": 0, "scalar-local": 0}
    for offset in range(1, len(groups), 2):
        index = int(groups[offset])
        ops = []
        for line in groups[offset + 1].splitlines():
            match = re.search(r"\|\s+(.*)$", line)
            if match and match[1].strip() and not match[1].startswith("local["):
                ops.append(match[1].strip())
        accesses = [(n, op) for n, op in enumerate(ops) if op.startswith("global.")]
        frame = int(ops[1].split()[1]) if accesses else 0
        calls = sorted(set(int(op.split()[1]) for op in ops if op.startswith("call ")))
        kind = "frameless" if not accesses else "void" if ops[-2] == "global.set 0" else "scalar-local"
        kinds[kind] += 1
        inventory[index] = {"frame": frame, "calls": calls}
        actual = proof["functions"][index]
        assert actual["index"] == index and actual["frameBytes"] == frame and actual["calls"] == calls
        expected = [(a["instruction"], "global." + a["op"] + " " + str(a["global"])) for a in actual["globalAccesses"]]
        assert accesses == expected, (name, index, accesses, expected, ops[:8])
    assert len(inventory) == len(proof["functions"])
    active, cumulative, depth = set(), {}, {}
    def visit(index):
        assert index not in active
        if index in cumulative:
            return
        active.add(index)
        item = inventory[index]
        for callee in item["calls"]:
            visit(callee)
        cumulative[index] = item["frame"] + max([cumulative[c] for c in item["calls"]] or [0])
        depth[index] = 1 + max([depth[c] for c in item["calls"]] or [0])
        active.remove(index)
    for index in inventory:
        visit(index)
        assert cumulative[index] == proof["functions"][index]["cumulativeFrameBytes"]
        assert depth[index] == proof["functions"][index]["maxCallDepth"]
    for item in proof["exports"].values():
        assert sum(inventory[i]["frame"] for i in item["frameBoundPath"]) == item["linearStackBytes"]
        assert cumulative[item["function"]] == item["linearStackBytes"]
        assert depth[item["function"]] == item["maxCallDepth"]
    results.append({"artifact": name, "functions": len(inventory), "epilogues": kinds,
                    "maxLinearStackBytes": max(cumulative[e["function"]] for e in proof["exports"].values()),
                    "maxCallDepth": max(depth[e["function"]] for e in proof["exports"].values())})
print(json.dumps({"tool": subprocess.check_output([sys.argv[1], "--version"], text=True).strip(),
                  "scope": "Independent disassembly frame/global/call inventories and chain arithmetic; control-flow safety remains the binary analyzer's proof.",
                  "results": results}, indent=2))
