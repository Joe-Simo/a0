#!/usr/bin/env bash
set -euo pipefail
source <native-toolchain>/toolchain-env.sh
export PATH=<native-toolchain>/bin:$PATH
export TMPDIR=<js-checkout>/.a0-tmp
cd <js-checkout>
node dist/tools/source-cost-bench.js --cross-backend \
  --baseline=<historical-checkout> \
  --artifact=<js-checkout>/.a0-tmp/js-final \
  --control-checkout=<c-control-checkout> \
  --control-artifact=<c-control-checkout>/.a0-tmp/c-control \
  --sysroot=<wasi-sysroot> \
  --builtins=<wasi-builtins> \
  --out=<js-checkout>/.a0-tmp/js-cost-quiet-20261018
