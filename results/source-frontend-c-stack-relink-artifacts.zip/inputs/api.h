#define SV_STATE a0t_r7_a128_u_a128_u_a128_u_a128_u_a128_u_a128_u_io
#define IR_STATE a0t_r2_a128_u_io
#define IR_RESULT a0t_r3_a128_u_u_io
#define FRONTEND_BEGIN(s,t,h,n) ((s)=a0_arena_parse_verify_begin((t),(h),(n)))
#define FRONTEND_UNIT(s,t,h,n) ((s)=a0_arena_source_unit((t),(h),(n)))
#define FRONTEND_RESUME(s,n) ((s)=a0_arena_verify_resume((s),(n)))
#define FRONTEND_STATUS(m) a0_arena_verify_status(m)
