/** Dormant owned-state proof. No parser, optimizer default or public compiler route calls it. */
import { analyzeAggregateContext } from './aggregate-call-demand.js';
import { deriveAggregateReturnVariant, functionFieldDemands, ioPaths, joinFieldDemand, planAggregateReturns, } from './aggregate-demand.js';
import { containsIo, isPrimitive, isScalar, LIMITS, typeEquals, validate, validateFunction, } from './core.js';
import { isEffectful, optimizeHostMemoryView, privateAggregateReturn, privateAggregateSubtree, } from './optimize.js';
import { rewriteReadAfterSet } from './read-after-set.js';
const nodeOperand = (id) => ({ kind: 'node', id });
const literal = (value) => ({ kind: 'u32', value });
const sameOperand = (a, b) => a.kind === b.kind &&
    (a.kind === 'node' && b.kind === 'node'
        ? a.id === b.id
        : a.kind === 'param' && b.kind === 'param'
            ? a.index === b.index
            : false);
function typeAt(type, path) {
    for (const index of path) {
        if (isPrimitive(type))
            throw new Error('owned fold path crosses a scalar');
        type = type.kind === 'arr' ? type.elem : type.fields[index];
    }
    return type;
}
function graph(roots) {
    const names = new Map(), visited = new Set(), functions = [];
    const visit = (fn) => {
        if (visited.has(fn))
            return;
        visited.add(fn);
        const identity = JSON.stringify([fn.params, fn.result, fn.nodes, fn.ret, fn.profile]);
        const previous = names.get(fn.name);
        if (previous !== undefined && previous !== identity)
            throw new Error(`inconsistent detached call graph: ${fn.name}`);
        names.set(fn.name, identity);
        for (const callee of fn.calls.values())
            visit(callee);
        if (previous === undefined)
            functions.push(fn);
    };
    roots.forEach(visit);
    return functions;
}
/**
 * Atomic final-record projection: keep one affine constructor, capturing only demanded
 * leaves of private aggregate children. No sibling IO projection forwards independently.
 * The caller supplies an internal variant name; the public input graph stays untouched.
 */
export function packPrivateFinalReturn(fn, paths, name) {
    if (fn.profile === 'strict')
        return { refusal: 'strict-profile' };
    if (fn.spec !== undefined)
        return { refusal: 'function-spec' };
    const last = fn.nodes.at(-1);
    if (fn.ret.kind !== 'node' ||
        last?.id !== fn.ret.id ||
        last.op !== 'rec' ||
        isPrimitive(fn.result) ||
        fn.result.kind !== 'rec')
        return { refusal: 'not-final-record' };
    const returnedIo = ioPaths(fn.result);
    if (returnedIo.length > 1 ||
        returnedIo.some((io) => !paths.some((path) => path.length <= io.length && path.every((part, i) => part === io[i]))))
        return { refusal: 'io-affinity' };
    for (let i = 0; i < paths.length; i++) {
        const path = paths[i];
        if (path === undefined ||
            path.length === 0 ||
            paths.some((other, j) => j !== i && other.length <= path.length && other.every((part, k) => part === path[k])))
            return { refusal: 'nonprivate-field' };
    }
    const used = new Set(fn.nodes.map((node) => node.id));
    let serial = 0;
    const added = [], fields = [];
    const values = paths.map((path) => {
        const first = path[0];
        if (first === undefined)
            return undefined;
        let value = last.args[first];
        if (value === undefined)
            return undefined;
        let type = typeAt(fn.result, [first]);
        if (path.length > 1 && !privateAggregateSubtree(fn, value))
            return undefined;
        for (const index of path.slice(1)) {
            if (isPrimitive(type) ||
                !Number.isInteger(index) ||
                index < 0 ||
                index >= (type.kind === 'arr' ? type.length : type.fields.length))
                return undefined;
            let id;
            do
                id = `returnfield${serial++}`;
            while (used.has(id));
            used.add(id);
            added.push({ id, op: type.kind === 'arr' ? 'get' : 'at', args: [value, literal(index)] });
            value = nodeOperand(id);
            type = typeAt(type, [index]);
        }
        fields.push(type);
        return value;
    });
    if (values.some((value) => value === undefined))
        return { refusal: 'nonprivate-field' };
    if (fn.nodes.length + added.length > LIMITS.maxNodesPerFunction)
        return { refusal: 'node-limit' };
    const packed = { ...last, args: values };
    return {
        fn: validateFunction({
            ...fn,
            name,
            result: { kind: 'rec', fields },
            nodes: [...fn.nodes.slice(0, -1), ...added, packed],
        }, fn.calls),
    };
}
/** Reuse the frozen return planner, including its IO affinity and expansion refusals. */
function projectReturn(fn, paths, context, reservedNames) {
    if (fn.spec !== undefined)
        return { refusal: 'function-spec' };
    const scope = graph([context, fn]);
    const taken = new Set(scope.map((f) => f.name));
    let serial = 0, name;
    do
        name = `foldcontext${serial++}`;
    while (taken.has(name));
    const nodes = [
        {
            id: 'result',
            op: 'call',
            callee: fn.name,
            args: fn.params.map((_, index) => ({ kind: 'param', index })),
        },
    ];
    const projections = new Map([['', nodeOperand('result')]]);
    const values = paths.map((path) => {
        let value = nodeOperand('result'), type = fn.result;
        for (const [part, index] of path.entries()) {
            if (isPrimitive(type))
                throw new Error('owned fold return path crosses a scalar');
            const key = path.slice(0, part + 1).join('/');
            let projected = projections.get(key);
            if (projected === undefined) {
                const id = `field${nodes.length}`;
                nodes.push({ id, op: type.kind === 'arr' ? 'get' : 'at', args: [value, literal(index)] });
                projected = nodeOperand(id);
                projections.set(key, projected);
            }
            value = projected;
            type = typeAt(type, [index]);
        }
        return value;
    });
    nodes.push({ id: 'packed', op: 'rec', args: values });
    if (nodes.length > LIMITS.maxNodesPerFunction)
        return { refusal: 'node-limit' };
    const caller = {
        name,
        params: fn.params,
        result: { kind: 'rec', fields: paths.map((p) => typeAt(fn.result, p)) },
        nodes,
        ret: nodeOperand('packed'),
    };
    const program = validate({ functions: [...scope, caller] });
    const plan = planAggregateReturns(program, reservedNames).find((p) => p.caller === name && p.node === 'result');
    if (plan?.refusal === 'node-limit')
        return { refusal: 'node-limit' };
    if (plan === undefined)
        return {};
    const detached = deriveAggregateReturnVariant(program, plan);
    if (detached === undefined)
        return {};
    return {
        fn: packPrivateFinalReturn(fn, plan.fields.map((field) => field.path), detached.name).fn ?? detached,
    };
}
/**
 * Replace only literal projection chains of an already-proved private root. Scalar captures
 * stay at their original nodes; an unknown aggregate use refuses instead of being reconstructed.
 */
function lowerRoot(nodes, ret, root, original, paths, replacements = new Map()) {
    const fields = new Map(paths.map((path, field) => [path.join('/'), field]));
    const aliases = new Map();
    const origin = (value) => value === undefined
        ? undefined
        : sameOperand(value, root)
            ? []
            : value.kind === 'node'
                ? aliases.get(value.id)
                : undefined;
    const out = [];
    for (const source of nodes) {
        const base = origin(source.args[0]);
        if (base !== undefined) {
            if (source.op === 'mov') {
                aliases.set(source.id, base);
                continue;
            }
            const index = source.args[1];
            const container = typeAt(original, base);
            if ((source.op !== 'at' && source.op !== 'get') ||
                index?.kind !== 'u32' ||
                isPrimitive(container))
                return undefined;
            const part = container.kind === 'arr' ? index.value % container.length : index.value;
            const path = [...base, part], type = typeAt(original, path);
            const field = fields.get(path.join('/'));
            if (field !== undefined) {
                out.push({ ...source, op: 'at', args: [root, literal(field)] });
                continue;
            }
            if (!isPrimitive(type)) {
                aliases.set(source.id, path);
                continue;
            }
            return undefined;
        }
        if (source.args.some((argument) => origin(argument) !== undefined))
            return undefined;
        out.push(replacements.get(source.id) ?? source);
    }
    return origin(ret) === undefined ? out : undefined;
}
/**
 * A call may return selected private fields without moving a borrowed observation across IO.
 * The private callee keeps its original argument types and every original body operation.
 * Partial aggregate captures require the shared HostMemory proof. For any other borrowed
 * field, its original caller projection must precede the next effect. No entry capture or
 * public-function substitution is performed; use only in an uninstrumented compile view.
 */
export function projectPrivateCallReturn(fn, callID, reservedNames) {
    const refuse = (refusal) => ({
        fn,
        refusal,
    });
    const scope = graph([fn]);
    if (scope.some((value) => value.profile === 'strict'))
        return refuse('strict-profile');
    if (scope.some((value) => value.spec !== undefined))
        return refuse('function-spec');
    const call = fn.nodes.find((node) => node.id === callID), callee = fn.calls.get(call?.callee ?? '');
    if (call?.op !== 'call' || callee === undefined || isPrimitive(callee.result))
        return refuse('not-a-call');
    const names = new Set([...reservedNames, ...scope.map((value) => value.name)]), program = validate({ functions: scope }), plan = planAggregateReturns(program, names).find((value) => value.caller === fn.name && value.node === callID);
    if (plan?.refusal === 'node-limit')
        return refuse('node-limit');
    if (plan === undefined || plan.refusal !== undefined)
        return refuse('projection-refused');
    const paths = plan.fields.map((field) => field.path), borrowed = new Set();
    for (const path of paths) {
        const type = typeAt(callee.result, path);
        if (type === 'io')
            continue;
        if (containsIo(type))
            return refuse('nonprivate-field');
        if (path.length > 1) {
            if (!privateAggregateSubtree(callee, callee.ret, path.slice(0, -1)))
                return refuse('nonprivate-field');
        }
        else if (isPrimitive(type) || !privateAggregateSubtree(callee, callee.ret, path))
            borrowed.add(path.join('/'));
    }
    const packed = packOwnedConsumers(fn, fn.nodes, nodeOperand(callID), callee.result, paths);
    if (packed.nodes === undefined)
        return refuse(packed.refusal ?? 'state-not-closed');
    // Scalars and whole borrowed subtrees retain the caller's original observation epoch.
    // Track only pure aliases/projections; lowerRoot below rejects every other root use.
    const aliases = new Map([[callID, []]]);
    let afterCall = false, effect = false;
    for (const node of packed.nodes) {
        if (node.id === callID) {
            afterCall = true;
            continue;
        }
        if (!afterCall)
            continue;
        const first = node.args[0], base = first?.kind === 'node' ? aliases.get(first.id) : undefined;
        if (base !== undefined) {
            if (node.op === 'mov')
                aliases.set(node.id, base);
            else if ((node.op === 'at' || node.op === 'get') && node.args[1]?.kind === 'u32') {
                const container = typeAt(callee.result, base);
                if (!isPrimitive(container)) {
                    const index = container.kind === 'arr' ? node.args[1].value % container.length : node.args[1].value;
                    const path = [...base, index];
                    if (effect && borrowed.has(path.join('/')))
                        return refuse('callback-epoch');
                    aliases.set(node.id, path);
                }
            }
        }
        effect ||= isEffectful(node, fn);
    }
    const projected = projectReturn(callee, paths, fn, names);
    if (projected.fn === undefined)
        return refuse(projected.refusal ?? 'projection-refused');
    const small = optimizeHostMemoryView(projected.fn).fn, nodes = lowerRoot(packed.nodes, fn.ret, nodeOperand(callID), callee.result, paths, new Map([[callID, { ...call, callee: small.name }]]));
    if (nodes === undefined)
        return refuse('state-not-closed');
    if (nodes.length > LIMITS.maxNodesPerFunction)
        return refuse('node-limit');
    const calls = new Map(fn.calls);
    calls.set(small.name, small);
    return {
        fn: validateFunction({ ...fn, nodes }, calls),
        callee: small,
        paths,
        requiresUninstrumentedEmission: true,
    };
}
/**
 * A closed private fold result may pass through a record before its scalar observation.
 * Narrow that record atomically too; keep all primitive siblings and the one IO edge.
 * Unknown whole/nested aggregate consumers refuse. This is not general constructor fusion.
 */
function packOwnedConsumers(fn, nodes, root, state, paths) {
    const aliases = new Map();
    const origin = (value) => value === undefined
        ? undefined
        : sameOperand(value, root)
            ? []
            : value.kind === 'node'
                ? aliases.get(value.id)
                : undefined;
    const demands = functionFieldDemands(fn);
    const used = new Set(nodes.map((node) => node.id));
    let serial = 0, current = [...nodes];
    for (const node of nodes) {
        const base = origin(node.args[0]);
        if (base !== undefined &&
            (node.op === 'at' || node.op === 'get') &&
            node.args[1]?.kind === 'u32') {
            const container = typeAt(state, base);
            if (!isPrimitive(container)) {
                const index = container.kind === 'arr' ? node.args[1].value % container.length : node.args[1].value;
                const path = [...base, index];
                if (!isPrimitive(typeAt(state, path)))
                    aliases.set(node.id, path);
            }
        }
        else if (base !== undefined && node.op === 'mov')
            aliases.set(node.id, base);
        if (node.op !== 'rec')
            continue;
        const affected = node.args.flatMap((value, field) => {
            const path = origin(value);
            return path !== undefined &&
                !isPrimitive(typeAt(state, path)) &&
                paths.some((selected) => selected.length > path.length && path.every((part, i) => part === selected[i]))
                ? [{ field, path, value }]
                : [];
        });
        if (affected.length === 0)
            continue;
        if (affected.length !== 1)
            return {};
        const entry = affected[0];
        if (entry === undefined)
            return {};
        const array = typeAt(state, entry.path), result = fn.types.get(node.id), demand = demands.get(node.id);
        if (isPrimitive(array) ||
            array.kind !== 'arr' ||
            !isScalar(array.elem) ||
            result === undefined ||
            isPrimitive(result) ||
            result.kind !== 'rec' ||
            demand === undefined ||
            demand === 'all')
            return {};
        const selected = paths.filter((path) => path.length === entry.path.length + 1 && entry.path.every((part, i) => part === path[i]));
        const selectedElements = new Set(selected.map((path) => path[entry.path.length]));
        const local = demand.filter((path) => path[0] === entry.field);
        const elements = local.map((path) => path[1]);
        if (elements.length === 0 ||
            local.some((path) => path[0] === entry.field &&
                (path.length !== 2 || !selectedElements.has(path[1]))))
            return {};
        const layout = result.fields.flatMap((_, field) => field === entry.field ? elements.map((element) => [field, element]) : [[field]]);
        const captures = elements.map((element) => {
            let id;
            do
                id = `foldconsumer${serial++}`;
            while (used.has(id));
            used.add(id);
            return { id, op: 'get', args: [entry.value, literal(element)] };
        });
        const replacement = {
            ...node,
            args: node.args.flatMap((value, field) => field === entry.field ? captures.map((capture) => nodeOperand(capture.id)) : [value]),
        };
        const expanded = current.flatMap((value) => value.id === node.id ? [...captures, value] : [value]);
        const packed = lowerRoot(expanded, fn.ret, nodeOperand(node.id), result, layout, new Map([[node.id, replacement]]));
        if (packed === undefined)
            return {};
        if (packed.length > LIMITS.maxNodesPerFunction)
            return { refusal: 'node-limit' };
        current = packed;
    }
    return { nodes: current };
}
/**
 * One bounded closure: `(scalar-array,io)` state, selected scalar elements, a private
 * initializer, and a recurrence whose projected body reads only those elements and the token.
 * It never narrows borrowed state, changes the original array modulus, unrolls IO, or replaces
 * public functions/interpreter graphs. Strict and instrumented emission remain outside this proof.
 */
export function projectOwnedScalarFold(fn, foldID, reservedNames) {
    const names = new Set([...reservedNames, ...graph([fn]).map((value) => value.name)]);
    const refuse = (refusal) => ({ fn, refusal });
    if (fn.profile === 'strict')
        return refuse('strict-profile');
    if (fn.spec !== undefined)
        return refuse('function-spec');
    const fold = fn.nodes.find((node) => node.id === foldID);
    if (fold?.op !== 'fold')
        return refuse('not-a-fold');
    const body = fn.calls.get(fold.callee ?? '');
    if (body?.profile === 'strict')
        return refuse('strict-profile');
    if (body?.spec !== undefined)
        return refuse('function-spec');
    const state = body?.params[0];
    if (body === undefined ||
        state === undefined ||
        isPrimitive(state) ||
        state.kind !== 'rec' ||
        !typeEquals(state, body.result) ||
        body.params.slice(2).some(containsIo))
        return refuse('unsupported-state');
    const ioField = state.fields.indexOf('io');
    if (ioField < 0 || ioPaths(state).length !== 1)
        return refuse('unsupported-state');
    const demand = functionFieldDemands(fn).get(fold.id);
    if (demand === undefined || demand === 'all')
        return refuse('whole-or-invalid-element-demand');
    const candidates = state.fields.flatMap((type, field) => !isPrimitive(type) &&
        type.kind === 'arr' &&
        isScalar(type.elem) &&
        demand.some((path) => path[0] === field && path.length > 1)
        ? [field]
        : []);
    if (candidates.length !== 1)
        return refuse('whole-or-invalid-element-demand');
    const arrayField = candidates[0];
    const array = state.fields[arrayField];
    if (array === undefined || isPrimitive(array) || array.kind !== 'arr')
        return refuse('unsupported-state');
    const selected = demand.filter((path) => path[0] === arrayField);
    if (selected.length === 0 ||
        selected.some((path) => path.length !== 2 || path[1] >= array.length))
        return refuse('whole-or-invalid-element-demand');
    const elements = selected.map((path) => path[1]);
    const paths = joinFieldDemand(demand, [[ioField]]);
    if (paths === 'all' || paths.some((path) => path[0] !== arrayField && path.length !== 1))
        return refuse('unsupported-state');
    if (state.fields.length !== 2) {
        const guarded = analyzeAggregateContext(fn)
            .functions.find((context) => context.fn === fn)
            ?.guardedFolds.find((site) => site.node === foldID);
        if (guarded === undefined)
            return refuse('state-not-closed');
        // This establishes the zero-or-one count only. The original dependency summary
        // deliberately treats a dynamic set as reading the entire old array. Prove the
        // precise state closure below, after read-after-set exposes its scalar dependency;
        // lowerRoot must reject every remaining unselected state read, including effects.
        if (!privateAggregateSubtree(body, body.ret, [arrayField]))
            return refuse('body-result-not-private');
    }
    const init = fold.args[1];
    const initNode = init?.kind === 'node' ? fn.nodes.find((node) => node.id === init.id) : undefined;
    if (initNode?.op !== 'rec' || initNode.args.length !== state.fields.length)
        return refuse('initializer-not-private');
    const uses = fn.nodes
        .flatMap((node) => node.args)
        .filter((value) => init !== undefined && sameOperand(value, init)).length +
        (init !== undefined && sameOperand(fn.ret, init) ? 1 : 0);
    if (uses !== 1)
        return refuse('initial-state-escapes');
    const page = initNode.args[arrayField];
    if (page === undefined)
        return refuse('initializer-not-private');
    const factoryNode = page.kind === 'node' ? fn.nodes.find((node) => node.id === page.id) : undefined;
    const factory = factoryNode?.op === 'call' ? fn.calls.get(factoryNode.callee ?? '') : undefined;
    if (!privateAggregateSubtree(fn, page))
        return refuse('initializer-not-private');
    const projected = projectReturn(body, paths, fn, names);
    if (projected.fn === undefined)
        return refuse(projected.refusal ?? 'projection-refused');
    names.add(projected.fn.name);
    const exposed = optimizeHostMemoryView(projected.fn).fn;
    const recurrence = rewriteReadAfterSet(exposed);
    const reduced = optimizeHostMemoryView(recurrence.fn).fn;
    const bodyNodes = lowerRoot(reduced.nodes, reduced.ret, { kind: 'param', index: 0 }, state, paths);
    if (bodyNodes === undefined)
        return refuse('state-not-closed');
    const smallState = { kind: 'rec', fields: paths.map((path) => typeAt(state, path)) };
    const loweredBody = optimizeHostMemoryView(validateFunction({ ...reduced, params: [smallState, ...reduced.params.slice(1)], nodes: bodyNodes }, reduced.calls)).fn;
    const used = new Set(fn.nodes.map((node) => node.id));
    let serial = 0;
    const captures = elements.map((element) => {
        let id;
        do
            id = `foldvalue${serial++}`;
        while (used.has(id));
        used.add(id);
        return { id, op: 'get', args: [page, literal(element)] };
    });
    const captured = new Map(elements.map((element, i) => [element, nodeOperand(captures[i].id)]));
    const initial = {
        ...initNode,
        args: paths.map((path) => path[0] === arrayField
            ? captured.get(path[1])
            : initNode.args[path[0]]),
    };
    const nodes = fn.nodes.flatMap((node) => node.id === initNode.id ? [...captures, initial] : [node]);
    const packedConsumers = packOwnedConsumers(fn, nodes, nodeOperand(fold.id), state, paths);
    if (packedConsumers.nodes === undefined)
        return refuse(packedConsumers.refusal ?? 'state-not-closed');
    const rewritten = lowerRoot(packedConsumers.nodes, fn.ret, nodeOperand(fold.id), state, paths, new Map([[fold.id, { ...fold, callee: loweredBody.name }]]));
    if (rewritten === undefined)
        return refuse('state-not-closed');
    if (rewritten.length > LIMITS.maxNodesPerFunction)
        return refuse('node-limit');
    const calls = new Map(fn.calls);
    calls.set(loweredBody.name, loweredBody);
    let view = optimizeHostMemoryView(validateFunction({ ...fn, nodes: rewritten }, calls)).fn;
    let factoryProjected = false;
    if (factoryNode !== undefined && factory !== undefined && privateAggregateReturn(factory)) {
        const factoryPaths = elements.map((element) => [element]);
        const variant = projectReturn(factory, factoryPaths, view, names);
        if (variant.fn !== undefined) {
            const factoryView = optimizeHostMemoryView(rewriteReadAfterSet(optimizeHostMemoryView(variant.fn).fn).fn).fn;
            const capture = lowerRoot(view.nodes, view.ret, nodeOperand(factoryNode.id), array, factoryPaths, new Map([[factoryNode.id, { ...factoryNode, callee: factoryView.name }]]));
            if (capture !== undefined) {
                const scope = new Map(view.calls);
                scope.set(factoryView.name, factoryView);
                view = optimizeHostMemoryView(validateFunction({ ...view, nodes: capture }, scope)).fn;
                factoryProjected = true;
            }
        }
    }
    return {
        fn: view,
        originalLength: array.length,
        ...(elements.length === 1 ? { element: elements[0] } : {}),
        elements,
        recurrenceSites: recurrence.sites.length,
        factoryProjected,
        requiresUninstrumentedEmission: true,
    };
}
/**
 * Detached composition of the bounded laws above. Public source Func objects are untouched;
 * only the returned compile graph substitutes bodies, with identical root names/signatures.
 * Reachability follows that graph, so unused original bodies need not be emitted beside it.
 * Conflicting private definitions receive reserved symbols, never a source-name exception.
 */
export function deriveAggregateCompileView(roots, reservedNames) {
    const original = graph(roots), names = new Set([...reservedNames, ...original.map((fn) => fn.name)]), sites = [];
    const base = { roots, functions: original, sites, requiresUninstrumentedEmission: true };
    if (original.some((fn) => fn.profile === 'strict'))
        return { ...base, refusal: 'strict-profile' };
    if (original.some((fn) => fn.spec !== undefined))
        return { ...base, refusal: 'function-spec' };
    let serial = 0;
    const publisher = (initial, publicNames) => {
        const sealed = new Map(), exported = new Set(publicNames.values()), definitions = new Map(initial.map((fn) => [
            fn.name,
            {
                identity: JSON.stringify([fn.params, fn.result, fn.nodes, fn.ret, fn.profile]),
                fn,
            },
        ]));
        const seal = (fn) => {
            const cached = sealed.get(fn);
            if (cached !== undefined)
                return cached;
            const children = new Map([...fn.calls].map(([name, child]) => [name, seal(child)])), calls = new Map([...children.values()].map((child) => [child.name, child])), nodes = fn.nodes.map((node) => ({
                ...node,
                ...(node.callee === undefined
                    ? {}
                    : { callee: children.get(node.callee).name }),
                ...(node.pred === undefined ? {} : { pred: children.get(node.pred).name }),
            })), identity = JSON.stringify([fn.params, fn.result, nodes, fn.ret, fn.profile]), publicName = publicNames.get(fn);
            let name = publicName ?? fn.name;
            const existing = definitions.get(name);
            if (publicName === undefined && existing?.identity === identity) {
                sealed.set(fn, existing.fn);
                return existing.fn;
            }
            if (existing !== undefined || (publicName === undefined && exported.has(name))) {
                do
                    name = `aggregateview${serial++}`;
                while (names.has(name));
            }
            names.add(name);
            const result = validateFunction({ ...fn, name, nodes }, calls);
            definitions.set(name, { identity, fn: result });
            sealed.set(fn, result);
            return result;
        };
        return seal;
    };
    // Safe optimization creates alternate callee bodies under their source names. Publish
    // every new graph before another planner sees it; final-only renaming is too late.
    const publish = publisher(original, new Map()), memo = new Map();
    const lower = (fn) => {
        const cached = memo.get(fn);
        if (cached !== undefined)
            return cached;
        let view = fn;
        for (const node of view.nodes)
            if (node.op === 'fold') {
                const proof = projectOwnedScalarFold(view, node.id, names);
                sites.push({
                    kind: 'fold',
                    fn: fn.name,
                    node: node.id,
                    ...(proof.refusal === undefined ? {} : { refusal: proof.refusal }),
                });
                if (proof.refusal === undefined)
                    view = publish(proof.fn);
            }
        for (const node of view.nodes)
            if (node.op === 'call' && !isPrimitive(view.types.get(node.id) ?? 'u32')) {
                const proof = projectPrivateCallReturn(view, node.id, names);
                sites.push({
                    kind: 'call',
                    fn: fn.name,
                    node: node.id,
                    ...(proof.refusal === undefined ? {} : { refusal: proof.refusal }),
                });
                if (proof.refusal === undefined)
                    view = publish(proof.fn);
            }
        const children = new Map([...view.calls].map(([name, child]) => [name, lower(child)])), calls = new Map([...children.values()].map((child) => [child.name, child])), nodes = view.nodes.map((node) => ({
            ...node,
            ...(node.callee === undefined
                ? {}
                : { callee: children.get(node.callee).name }),
            ...(node.pred === undefined ? {} : { pred: children.get(node.pred).name }),
        })), result = publish(validateFunction({ ...view, nodes }, calls));
        memo.set(fn, result);
        return result;
    };
    const lowered = roots.map(lower), seal = publisher([], new Map(lowered.map((fn, i) => [fn, roots[i].name])));
    const published = lowered.map(seal), functions = graph(published);
    validate({ functions });
    return { roots: published, functions, sites, requiresUninstrumentedEmission: true };
}
//# sourceMappingURL=owned-scalar-fold.js.map