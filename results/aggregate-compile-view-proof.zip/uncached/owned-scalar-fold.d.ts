/** Dormant owned-state proof. No parser, optimizer default or public compiler route calls it. */
import { type LogicalPath } from './aggregate-demand.js';
import { type TypedFunc } from './core.js';
export type OwnedScalarFoldRefusal = 'strict-profile' | 'function-spec' | 'not-a-fold' | 'unsupported-state' | 'whole-or-invalid-element-demand' | 'initial-state-escapes' | 'initializer-not-private' | 'state-not-closed' | 'body-result-not-private' | 'projection-refused' | 'node-limit';
export interface OwnedScalarFoldView {
    readonly fn: TypedFunc;
    readonly refusal?: OwnedScalarFoldRefusal;
    readonly originalLength?: number;
    readonly element?: number;
    readonly elements?: readonly number[];
    readonly recurrenceSites?: number;
    readonly factoryProjected?: boolean;
    /** The detached graph is not a trap-instrumented or interpreter replacement. */
    readonly requiresUninstrumentedEmission?: boolean;
}
export interface PrivateReturnPacking {
    readonly fn?: TypedFunc;
    readonly refusal?: 'strict-profile' | 'function-spec' | 'not-final-record' | 'io-affinity' | 'nonprivate-field' | 'node-limit';
}
export interface PrivateCallReturnView {
    readonly fn: TypedFunc;
    readonly paths?: readonly LogicalPath[];
    readonly callee?: TypedFunc;
    readonly refusal?: 'strict-profile' | 'function-spec' | 'not-a-call' | 'projection-refused' | 'nonprivate-field' | 'callback-epoch' | 'state-not-closed' | 'node-limit';
    readonly requiresUninstrumentedEmission?: boolean;
}
export interface AggregateCompileSite {
    readonly kind: 'call' | 'fold';
    readonly fn: string;
    readonly node: string;
    readonly refusal?: string;
}
export interface AggregateCompileView {
    readonly roots: readonly TypedFunc[];
    readonly functions: readonly TypedFunc[];
    readonly sites: readonly AggregateCompileSite[];
    readonly refusal?: 'strict-profile' | 'function-spec';
    readonly requiresUninstrumentedEmission: true;
}
/**
 * Atomic final-record projection: keep one affine constructor, capturing only demanded
 * leaves of private aggregate children. No sibling IO projection forwards independently.
 * The caller supplies an internal variant name; the public input graph stays untouched.
 */
export declare function packPrivateFinalReturn(fn: TypedFunc, paths: readonly LogicalPath[], name: string): PrivateReturnPacking;
/**
 * A call may return selected private fields without moving a borrowed observation across IO.
 * The private callee keeps its original argument types and every original body operation.
 * Partial aggregate captures require the shared HostMemory proof. For any other borrowed
 * field, its original caller projection must precede the next effect. No entry capture or
 * public-function substitution is performed; use only in an uninstrumented compile view.
 */
export declare function projectPrivateCallReturn(fn: TypedFunc, callID: string, reservedNames: Iterable<string>): PrivateCallReturnView;
/**
 * One bounded closure: `(scalar-array,io)` state, selected scalar elements, a private
 * initializer, and a recurrence whose projected body reads only those elements and the token.
 * It never narrows borrowed state, changes the original array modulus, unrolls IO, or replaces
 * public functions/interpreter graphs. Strict and instrumented emission remain outside this proof.
 */
export declare function projectOwnedScalarFold(fn: TypedFunc, foldID: string, reservedNames: Iterable<string>): OwnedScalarFoldView;
/**
 * Detached composition of the bounded laws above. Public source Func objects are untouched;
 * only the returned compile graph substitutes bodies, with identical root names/signatures.
 * Reachability follows that graph, so unused original bodies need not be emitted beside it.
 * Conflicting private definitions receive reserved symbols, never a source-name exception.
 */
export declare function deriveAggregateCompileView(roots: readonly TypedFunc[], reservedNames: Iterable<string>): AggregateCompileView;
