#!/usr/bin/env python3
"""Read-only binary inspection of the saved native bootstrap compiler image.

No WebAssembly instance is created and no compiler/test is executed. Offsets in
instruction traces are relative to the first instruction after local declarations;
module_offset is the corresponding absolute byte offset in the saved Wasm file.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def digest(data):
    return hashlib.sha256(data).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("image", type=Path)
parser.add_argument("--root", type=Path, default=Path.cwd())
args = parser.parse_args()
root = args.root.resolve()
image = args.image.resolve()
data = image.read_bytes()
assert data[:8] == b"\x00asm\x01\x00\x00\x00"


def number(at, signed=False):
    value = shift = 0
    while True:
        byte = data[at]
        at += 1
        value |= (byte & 127) << shift
        shift += 7
        if byte < 128:
            if signed and byte & 64:
                value -= 1 << shift
            return value, at


sections = {}
at = 8
while at < len(data):
    section_id = data[at]
    size, start = number(at + 1)
    sections[section_id] = (start, start + size)
    at = start + size

at = sections[1][0]
count, at = number(at)
types = []
for _ in range(count):
    assert data[at] == 0x60
    at += 1
    width, at = number(at)
    params = list(data[at:at + width])
    at += width
    width, at = number(at)
    result = list(data[at:at + width])
    at += width
    types.append({"parameters": params, "results": result})

at = sections[3][0]
count, at = number(at)
function_types = []
for _ in range(count):
    index, at = number(at)
    function_types.append(index)

at = sections[5][0]
count, at = number(at)
memories = []
for _ in range(count):
    flags, at = number(at)
    minimum, at = number(at)
    maximum = None
    if flags & 1:
        maximum, at = number(at)
    memories.append({"minimum_pages": minimum, "maximum_pages": maximum})

at = sections[6][0]
count, at = number(at)
globals_ = []
for index in range(count):
    value_type, mutable, opcode = data[at:at + 3]
    at += 3
    assert opcode == 0x41
    value, at = number(at, True)
    assert data[at] == 0x0b
    at += 1
    globals_.append({"index": index, "type": value_type,
                     "mutable": mutable, "value": value, "hex": hex(value)})

at = sections[7][0]
count, at = number(at)
exports = []
for _ in range(count):
    width, at = number(at)
    name = data[at:at + width].decode()
    at += width
    kind = data[at]
    index, at = number(at + 1)
    exports.append({"name": name, "kind": kind, "index": index})

at = sections[10][0]
count, at = number(at)
bodies = []
for _ in range(count):
    width, start = number(at)
    bodies.append((start, start + width))
    at = start + width

NAMES = {
    0x00: "unreachable", 0x02: "block", 0x03: "loop", 0x04: "if",
    0x05: "else", 0x0b: "end", 0x0c: "br", 0x0d: "br_if",
    0x0f: "return", 0x10: "call", 0x1a: "drop", 0x1b: "select",
    0x20: "local.get", 0x21: "local.set", 0x22: "local.tee",
    0x23: "global.get", 0x24: "global.set", 0x28: "i32.load",
    0x36: "i32.store", 0x41: "i32.const", 0x45: "i32.eqz",
    0x46: "i32.eq", 0x47: "i32.ne", 0x49: "i32.lt_u",
    0x4b: "i32.gt_u", 0x4d: "i32.le_u", 0x4f: "i32.ge_u",
    0x6a: "i32.add", 0x6b: "i32.sub", 0x6c: "i32.mul",
    0x6e: "i32.div_u", 0x70: "i32.rem_u", 0x71: "i32.and",
    0x72: "i32.or", 0x73: "i32.xor", 0x74: "i32.shl", 0x76: "i32.shr_u",
}


def disassemble(index):
    start, end = bodies[index]
    at = start
    count, at = number(at)
    locals_ = []
    for _ in range(count):
        width, at = number(at)
        locals_.append({"count": width, "type": data[at]})
        at += 1
    instructions_start = at
    instructions = []
    while at < end:
        offset = at
        opcode = data[at]
        at += 1
        operands = []
        if opcode in [0x02, 0x03, 0x04]:
            operands = [data[at]]
            at += 1
        elif opcode in [0x0c, 0x0d, 0x10, 0x20, 0x21, 0x22, 0x23, 0x24]:
            value, at = number(at)
            operands = [value]
        elif opcode in [0x28, 0x36]:
            alignment, at = number(at)
            displacement, at = number(at)
            operands = [alignment, displacement]
        elif opcode == 0x41:
            value, at = number(at, True)
            operands = [value]
        elif opcode == 0xfc:
            subopcode, at = number(at)
            assert subopcode in [10, 11]
            operands = [subopcode]
            for _ in range(2 if subopcode == 10 else 1):
                value, at = number(at)
                operands.append(value)
        else:
            assert opcode in NAMES, (index, offset, opcode)
        instructions.append({
            "offset": offset - instructions_start,
            "module_offset": offset,
            "operation": NAMES.get(opcode, "bulk-memory"),
            "operands": operands,
            "raw_hex": data[offset:at].hex(),
        })
    return {"index": index, "type_index": function_types[index],
            "signature": types[function_types[index]], "local_groups": locals_,
            "body_start": start, "instructions_start": instructions_start,
            "body_end": end, "body_sha256": digest(data[start:end]),
            "instructions": instructions}


functions = [disassemble(i) for i in [119, 396, 397, 398, 408, 411]]
wkmod = functions[-1]
assert len(wkmod["signature"]["parameters"]) == 21
ops = {row["offset"]: row for row in wkmod["instructions"]}
assert (ops[1515]["operation"], ops[1515]["operands"]) == ("local.get", [11])
assert (ops[1645]["operation"], ops[1645]["operands"]) == ("local.get", [22])
assignments = [row for row in wkmod["instructions"]
               if row["operation"] in ["local.set", "local.tee"]
               and row["operands"] == [22]]
assert [row["offset"] for row in assignments if row["offset"] < 1650] == [34]
source_paths = [
    "compiler/emit_wasm.a0", "compiler/wasm_code.a0", "src/wasm.ts",
    "tools/selfhost-wasm.ts", "test/native-wasm-bootstrap.controls.ts",
    str(image.parent.relative_to(root) / "native/a0w/compiler-source.a0"),
]
sources = []
for path in source_paths:
    content = (root / path).read_bytes()
    sources.append({"path": path, "bytes": len(content), "sha256": digest(content)})

report = {
    "inspection": "Static binary decoding only; no module execution, compiler build, test, or patch.",
    "git_head_at_inspection": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "git_tree_at_inspection": subprocess.check_output(
        ["git", "rev-parse", "HEAD^{tree}"], cwd=root, text=True).strip(),
    "image": {"path": str(image.relative_to(root)), "bytes": len(data), "sha256": digest(data)},
    "sources": sources,
    "memories": memories, "globals": globals_, "exports": exports,
    "defined_functions": len(bodies),
    "function_name_mapping": {
        "method": "Structural matching to source; image exports only emitwasmio and has no function-name map.",
        "119": "wauln", "396": "wkhelp", "397": "wkhsum", "398": "wkbsz",
        "408": "owned variant of wkhsumst", "411": "wkmod",
    },
    "source_locations": {
        "size_sum": "compiler/emit_wasm.a0:19264-19273; bw fold wkcszt p11 0 p1 false p15",
        "loop_body": "compiler/emit_wasm.a0:18949-18955 wkcszt; 18944-18947 wkcszg",
        "entry_test": "compiler/emit_wasm.a0:12179 wxlst calls wxlim",
        "backedge": "compiler/emit_wasm.a0:12712 wxtend calls wxlim at 12844",
        "bound_resolution": "compiler/emit_wasm.a0:12126 wxlim; 937 wxres; 1082 wxpsh",
        "local_mapping": "compiler/wasm_code.a0:165 wfzmap keeps parameters unchanged",
        "typescript_counterpart": "src/wasm.ts:3178 counted; entry limit() at3189 and backedge limit() at3201",
        "host_io": "test/native-wasm-bootstrap.controls.ts:140 ioModule places IO at __heap_base",
    },
    "critical_loop": [row for row in wkmod["instructions"] if 1503 <= row["offset"] <= 1650],
    "stale_local_definition": [row for row in wkmod["instructions"] if row["offset"] <= 103],
    "all_local_22_assignments": assignments,
    "finding": "Entry guard reads parameter11, but the same loop's backedge reads local22. Local22 was last assigned K[0]/ph0 at offset34. Exact faulty emission pass is not established by this static trace.",
    "reported_bad_leb": {"bytes": [129, 128, 160, 17], "value": 36175873, "hex": "0x2280001"},
    "functions": functions,
}
print(json.dumps(report, indent=2))
