import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {a0WasmFromTables,WASM_TOOL_INPUT,WASM_TOOL_OUTPUT} from '../dist/tools/selfhost-wasm.js';
import {parseAndValidate} from '../dist/src/core.js';
const dir='<control-run>';
const image=await readFile(dir+'/selfhost-emitter.wasm');
const {instance}=await WebAssembly.instantiate(image,{});
const m=instance.exports.memory;
const pointer=Number(instance.exports.__heap_base.value)>>>0;
const words=WASM_TOOL_INPUT+WASM_TOOL_OUTPUT+3;
const end=pointer+words*4;
if(end>m.buffer.byteLength)m.grow(Math.ceil((end-m.buffer.byteLength)/65536));
console.log({pointer,pages:m.buffer.byteLength/65536,stack:instance.exports.__stack_pointer});
let request=0;
const transport=input=>{
 const io=new Uint32Array(m.buffer,pointer,words);io.fill(0);io.set(input);io[WASM_TOOL_INPUT]=input.length;
 const code=instance.exports.a0_emitwasmio(pointer)>>>0;
 const result=new Uint32Array(m.buffer,pointer,words),n=result[words-1];
 const out=result.slice(WASM_TOOL_INPUT+2,WASM_TOOL_INPUT+2+n);
 const native=spawnSync(dir+'/native/a0w/a0w',{input:Buffer.from(Uint32Array.from(input).buffer),maxBuffer:64<<20});
 const expected=new Uint32Array(native.stdout.buffer,native.stdout.byteOffset,native.stdout.length/4).slice();
 const diffs=[];for(let i=0;i<Math.max(out.length,expected.length);i++)if(out[i]!==expected[i])diffs.push({i,wasm:out[i],native:expected[i]});
 console.log({request,mode:input[0],input:input.length,code,n,nativeCode:native.status,expected:expected.length,position:result[WASM_TOOL_INPUT+1],diffs:diffs.slice(0,20)});
 awaitNoopWrite(input,out,expected,request++);
 return {code,out};
};
function awaitNoopWrite(input,out,expected,i){
 // retain exact requests, actual responses, and baseline responses for independent replay.
 writes.push(writeFile(dir+'/debug-'+i+'-request.bin',Buffer.from(Uint32Array.from(input).buffer)));
 writes.push(writeFile(dir+'/debug-'+i+'-wasm.bin',Buffer.from(out.buffer)));
 writes.push(writeFile(dir+'/debug-'+i+'-native.bin',Buffer.from(expected.buffer)));
}
const writes=[];
const p=parseAndValidate('fn body u32 u32 -> u32\nret add p0 p1\nend\nfn probe u32 -> u32\nr fold body 7 p0\nret r\nend\n');
for(const optimize of [false,true]){
try{const actual=a0WasmFromTables(transport,p,{ioInputCapacity:1,ioOutputCapacity:1},optimize);console.log({optimize,valid:WebAssembly.validate(actual.bytes),bytes:actual.bytes.length});writes.push(writeFile(dir+'/debug-module-'+optimize+'.wasm',actual.bytes));}
catch(e){console.log(String(e));}
}
await Promise.all(writes);
