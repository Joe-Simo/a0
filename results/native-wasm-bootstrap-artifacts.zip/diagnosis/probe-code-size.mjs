import {readFile,writeFile} from 'node:fs/promises';
import {link} from '../dist/src/link.js';
import {bootstrapProgramClosure} from '../dist/tools/bootstrap-source.js';
import {a0WasmFromTables,typescriptWasm} from '../dist/tools/selfhost-wasm.js';
const dir='<control-run>';
const linked=(await link('compiler/boot.a0',p=>readFile(p,'utf8'))).program;
for(const root of ['wkcszt','wkhsumst']){
 const p=bootstrapProgramClosure(linked,[root]);
 const layout={ioInputCapacity:2097152,ioOutputCapacity:4194304,exports:[root]};
 for(const backend of ['a0','ts']){
  const image=backend==='a0'?a0WasmFromTables(dir+'/native/a0w/a0w',p,layout).bytes:typescriptWasm(p,layout,false);
  await writeFile(dir+'/debug-'+root+'-'+backend+'.wasm',image);
  const {instance}=await WebAssembly.instantiate(image,{}),m=instance.exports.memory;
  const base=Number(instance.exports.__heap_base.value)>>>0;
  const bytes=base+32*1024*1024;if(bytes>m.buffer.byteLength)m.grow(Math.ceil((bytes-m.buffer.byteLength)/65536));
  const u=new Uint32Array(m.buffer);
  let value;
  if(root==='wkcszt'){
   const v=base,t=v+256*128*4;u[t/4+3]=0;u[v/4+6]=6;
   value=instance.exports.a0_wkcszt(0,0,v,0,t)>>>0;
  }else{
   const out=base,state=base+32,io=base+64;u[state/4]=io;u[state/4+1]=0;
   value=instance.exports.a0_wkhsumst(out,state,0,1,1,0,0,0)>>>0;
   value={raw:value,output:[...u.slice(out/4,out/4+2)],state:[...u.slice(state/4,state/4+2)]};
  }
  console.log({root,backend,functions:p.functions.length,bytes:image.length,base,value});
 }
}
