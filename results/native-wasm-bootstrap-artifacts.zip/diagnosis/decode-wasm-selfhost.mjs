import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const dir='<control-run>';
const sha=b=>createHash('sha256').update(b).digest('hex');
function uleb(b,at){let n=0,s=0,i=at;for(;;){const v=b[i++];if(v===undefined)throw Error('truncated');n+=(v&127)*2**s;if(v<128)return{n,next:i};s+=7;if(s>35)throw Error('invalid');}}
function sections(b){const out=[];for(let at=8;at<b.length;){const start=at,id=b[at++],size=uleb(b,at);out.push({id,offset:start,payloadOffset:size.next,declaredBytes:size.n,availableBytes:b.length-size.next,sizeLEB:[...b.slice(at,size.next)]});at=size.next+size.n;}return out;}
const observed=[];
for(const [optimize,request]of [[false,1],[true,6]]){
 const row={optimize};
 for(const kind of ['native','wasm']){
  const raw=await readFile(`${dir}/debug-${request}-${kind}.bin`);
  const words=new Uint32Array(raw.buffer,raw.byteOffset,raw.length/4);
  const bytes=Uint8Array.from(words);
  await writeFile(`${dir}/debug-child-${optimize}-${kind}.wasm`,bytes);
  const value={bytes:bytes.length,sha256:sha(bytes),valid:WebAssembly.validate(bytes),sections:sections(bytes)};
  try{
   const {instance}=await WebAssembly.instantiate(bytes,{});
   value.executions=[0,1,0xffffffff].map(input=>({input,actual:instance.exports.a0_probe(input)>>>0,expected:(input+21)>>>0}));
  }catch(error){value.instantiationError=String(error);}
  row[kind]=value;
 }
 observed.push(row);
}
await writeFile(`${dir}/decoded-selfhost-children.json`,JSON.stringify(observed,null,2)+'\n');
console.log(JSON.stringify(observed,null,2));
